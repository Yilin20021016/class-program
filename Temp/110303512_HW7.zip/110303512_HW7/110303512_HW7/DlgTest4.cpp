// DlgTest4.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW7.h"
#include "DlgTest4.h"
#include "afxdialogex.h"


// CDlgTest4 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest4, CDialogEx)

CDlgTest4::CDlgTest4(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG4, pParent)
	, m_num1(0)
	, m_num2(0)
	, m_num3(0)
	, m_out1(0)
	, m_out2(0)
	, m_out3(0)
{

}

CDlgTest4::~CDlgTest4()
{
}

void CDlgTest4::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_num1);
	DDV_MinMaxInt(pDX, m_num1, 0, 9);
	DDX_Text(pDX, IDC_EDIT2, m_num2);
	DDV_MinMaxInt(pDX, m_num2, 0, 9);
	DDX_Text(pDX, IDC_EDIT3, m_num3);
	DDV_MinMaxInt(pDX, m_num3, 0, 9);
	DDX_Text(pDX, IDC_EDIT4, m_out1);
	DDX_Text(pDX, IDC_EDIT6, m_out2);
	DDX_Text(pDX, IDC_EDIT5, m_out3);
}


BEGIN_MESSAGE_MAP(CDlgTest4, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest4::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CDlgTest4::OnBnClickedButton2)
END_MESSAGE_MAP()


// CDlgTest4 �T���B�z�`��


void CDlgTest4::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	srand(time(NULL));
	m_num1 = rand() % 10;
	m_num2 = rand() % 10;
	m_num3 = rand() % 10;
	UpdateData(FALSE);
}


void CDlgTest4::OnBnClickedButton2()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	if (m_num1 > m_num2&&m_num1 > m_num3)
	{
		m_out1 = m_num1;
		if (m_num2 > m_num3)
		{
			m_out2 = m_num2;
			m_out3 = m_num3;
		}
		else
		{
			m_out2 = m_num3;
			m_out3 = m_num2;
		}
	}
	else if (m_num2 > m_num1&&m_num2 > m_num3)
	{
		m_out1 = m_num2;
		if (m_num2 > m_num1&&m_num2 > m_num3)
		{
			if (m_num1 > m_num3)
			{
				m_out2 = m_num1;
				m_out3 = m_num3;
			}
			else
			{
				m_out2 = m_num3;
				m_out3 = m_num1;
			}
		}
	}
	else if (m_num3 > m_num1&&m_num3 > m_num2)
	{
		m_out1 = m_num3;
		if (m_num1 > m_num2)
		{
			m_out2 = m_num1;
			m_out3 = m_num2;
		}
		else
		{
			m_out2 = m_num2;
			m_out3 = m_num1;
		}
	}
	UpdateData(FALSE);
}
