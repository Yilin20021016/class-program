#pragma once


// CDlgTest7 ��ܤ��

class CDlgTest7 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest7)

public:
	CDlgTest7(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest7();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG7 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	int m_11;
	int m_12;
	int m_13;
	int m_21;
	int m_22;
	int m_23;
	int m_31;
	int m_32;
	int m_33;
	int m_output;
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton3();
};
