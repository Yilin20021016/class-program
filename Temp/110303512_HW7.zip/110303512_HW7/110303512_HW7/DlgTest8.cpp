// DlgTest8.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW7.h"
#include "DlgTest8.h"
#include "afxdialogex.h"


// CDlgTest8 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest8, CDialogEx)

CDlgTest8::CDlgTest8(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG8, pParent)
{

}

CDlgTest8::~CDlgTest8()
{
}

void CDlgTest8::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgTest8, CDialogEx)
END_MESSAGE_MAP()


// CDlgTest8 �T���B�z�`��
