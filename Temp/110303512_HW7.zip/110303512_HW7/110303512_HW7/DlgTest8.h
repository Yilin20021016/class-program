#pragma once


// CDlgTest8 ��ܤ��

class CDlgTest8 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest8)

public:
	CDlgTest8(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest8();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG8 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
};
