// DlgTest5.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW7.h"
#include "DlgTest5.h"
#include "afxdialogex.h"
#include <vector>
using namespace std;



// CDlgTest5 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest5, CDialogEx)

CDlgTest5::CDlgTest5(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG5, pParent)
	, m_input(0)
	, m_output(0)
{

}

CDlgTest5::~CDlgTest5()
{
}

void CDlgTest5::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_input);
	DDX_Text(pDX, IDC_EDIT2, m_output);
}


BEGIN_MESSAGE_MAP(CDlgTest5, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest5::OnBnClickedButton1)
END_MESSAGE_MAP()


// CDlgTest5 �T���B�z�`��


void CDlgTest5::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	srand(time(NULL));
	int num = 100000;
	vector<int> A;

	for (int i = 0; i < num; i++) 
	{
		int tmp = rand() % 6 + 1;
		A.push_back(tmp);
	}

	int count = 0;
	for (int i = 0; i < num; i++) 
	{
		if (A[i] == m_input)
			count++;
	}

	m_output = (double)count / num;
	UpdateData(FALSE);
}
