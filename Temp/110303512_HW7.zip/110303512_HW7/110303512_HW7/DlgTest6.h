#pragma once


// CDlgTest6 ��ܤ��

class CDlgTest6 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest6)

public:
	CDlgTest6(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest6();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG6 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	int m_max1;
	int m_max5;
	int m_max10;
	int m_max50;
	int m_max100;
	int m_min1;
	int m_min5;
	int m_min10;
	int m_min50;
	int m_min100;
	double m_avg1;
	double m_avg5;
	double m_avg10;
	double m_avg50;
	double m_avg100;
	afx_msg void OnBnClickedButton1();
};
