// DlgTest2.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW7.h"
#include "DlgTest2.h"
#include "afxdialogex.h"


// CDlgTest2 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest2, CDialogEx)

CDlgTest2::CDlgTest2(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG2, pParent)
	, m_x(0)
	, m_y(0)
{

}

CDlgTest2::~CDlgTest2()
{
}

void CDlgTest2::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_x);
	DDX_Text(pDX, IDC_EDIT2, m_y);
}


BEGIN_MESSAGE_MAP(CDlgTest2, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest2::OnBnClickedButton1)
END_MESSAGE_MAP()


// CDlgTest2 �T���B�z�`��


void CDlgTest2::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	int sum = 0;
	sum = m_x + m_y;
	CString o2;
	o2.Format(_T("x + y = %d"), sum);
	AfxMessageBox(o2);
	UpdateData(FALSE);
}
