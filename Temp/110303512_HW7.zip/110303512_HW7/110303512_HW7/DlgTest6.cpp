// DlgTest6.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW7.h"
#include "DlgTest6.h"
#include "afxdialogex.h"
#include <vector>
using namespace std;


// CDlgTest6 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest6, CDialogEx)

CDlgTest6::CDlgTest6(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG6, pParent)
	, m_max1(0)
	, m_max5(0)
	, m_max10(0)
	, m_max50(0)
	, m_max100(0)
	, m_min1(0)
	, m_min5(0)
	, m_min10(0)
	, m_min50(0)
	, m_min100(0)
	, m_avg1(0)
	, m_avg5(0)
	, m_avg10(0)
	, m_avg50(0)
	, m_avg100(0)
{

}

CDlgTest6::~CDlgTest6()
{
}

void CDlgTest6::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT18, m_max1);
	DDX_Text(pDX, IDC_EDIT7, m_max5);
	DDX_Text(pDX, IDC_EDIT8, m_max10);
	DDX_Text(pDX, IDC_EDIT14, m_max50);
	DDX_Text(pDX, IDC_EDIT24, m_max100);
	DDX_Text(pDX, IDC_EDIT19, m_min1);
	DDX_Text(pDX, IDC_EDIT1, m_min5);
	DDX_Text(pDX, IDC_EDIT9, m_min10);
	DDX_Text(pDX, IDC_EDIT16, m_min50);
	DDX_Text(pDX, IDC_EDIT26, m_min100);
	DDX_Text(pDX, IDC_EDIT17, m_avg1);
	DDX_Text(pDX, IDC_EDIT2, m_avg5);
	DDX_Text(pDX, IDC_EDIT10, m_avg10);
	DDX_Text(pDX, IDC_EDIT15, m_avg50);
	DDX_Text(pDX, IDC_EDIT25, m_avg100);
}


BEGIN_MESSAGE_MAP(CDlgTest6, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest6::OnBnClickedButton1)
END_MESSAGE_MAP()


// CDlgTest6 �T���B�z�`��


void CDlgTest6::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	srand(time(NULL));

	vector<int> A, B, C, D, E;
	int i,sum=0;
	int num = 1000;

	UpdateData(TRUE);

	m_max1 = 0, m_max5 = 0, m_max10 = 0, m_max50 = 0, m_max100 = 0;
	m_min1 = 9999, m_min5 = 9999, m_min10 = 9999, m_min50 = 9999, m_min100 = 9999;
	m_avg1 = 0, m_avg5 = 0, m_avg10 = 0, m_avg50 = 0, m_avg100 = 0;

	for (i = 0; i < num; i++) 
	{
		A.push_back(rand());
		if (m_max1 < A[i]) m_max1 = A[i];
		if (m_min1 > A[i]) m_min1 = A[i];
		sum += A[i];
	}
	m_avg1 = (double)sum / num;
	sum = 0;

	num = 5000;
	for (i = 0; i < num; i++)
	{
		B.push_back(rand());
		if (m_max5 < B[i]) m_max5 = B[i];
		if (m_min5 > B[i]) m_min5 = B[i];
		sum += B[i];
	}
	m_avg5 = (double)sum / num;
	sum = 0;

	num = 10000;
	for (i = 0; i < num; i++)
	{
		C.push_back(rand());
		if (m_max10 < C[i]) m_max10 = C[i];
		if (m_min10 > C[i]) m_min10 = C[i];
		sum += C[i];
	}
	m_avg10 = (double)sum / num;
	sum = 0;

	num = 50000;
	for (i = 0; i < num; i++)
	{
		D.push_back(rand());
		if (m_max50 < D[i]) m_max50 = D[i];
		if (m_min50 > D[i]) m_min50 = D[i];
		sum += D[i];
	}
	m_avg50 = (double)sum / num;
	sum = 0;

	num = 100000;
	for (i = 0; i < num; i++)
	{
		E.push_back(rand());
		if (m_max100 < E[i]) m_max100 = E[i];
		if (m_min100 > E[i]) m_min100 = E[i];
		sum += E[i];
	}
	m_avg100 = (double)sum / num;
	sum = 0;

	UpdateData(FALSE);
}