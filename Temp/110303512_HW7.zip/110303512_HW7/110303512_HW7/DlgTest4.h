#pragma once


// CDlgTest4 ��ܤ��

class CDlgTest4 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest4)

public:
	CDlgTest4(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest4();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG4 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	int m_num1;
	int m_num2;
	int m_num3;
	int m_out1;
	int m_out2;
	int m_out3;
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
};
