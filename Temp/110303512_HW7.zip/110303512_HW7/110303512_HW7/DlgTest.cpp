// DlgTest.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW7.h"
#include "DlgTest.h"
#include "afxdialogex.h"


// CDlgTest ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest, CDialogEx)

CDlgTest::CDlgTest(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, m_input(0)
{

}

CDlgTest::~CDlgTest()
{
}

void CDlgTest::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_input);
}


BEGIN_MESSAGE_MAP(CDlgTest, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON2, &CDlgTest::OnBnClickedButton2)
END_MESSAGE_MAP()


// CDlgTest �T���B�z�`��


void CDlgTest::OnBnClickedButton2()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	int i = m_input;
	CString o2;
	o2.Format(_T("%d"), i);
	AfxMessageBox(o2);
}
