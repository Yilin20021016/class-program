#pragma once


// CDlgTest3 ��ܤ��

class CDlgTest3 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest3)

public:
	CDlgTest3(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest3();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG3 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	CString m_input;
	CString m_output;
	afx_msg void OnBnClickedButton1();
};
