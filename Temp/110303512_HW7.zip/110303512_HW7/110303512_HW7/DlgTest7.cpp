// DlgTest7.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW7.h"
#include "DlgTest7.h"
#include "afxdialogex.h"


// CDlgTest7 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest7, CDialogEx)

CDlgTest7::CDlgTest7(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG7, pParent)
	, m_11(0)
	, m_12(0)
	, m_13(0)
	, m_21(0)
	, m_22(0)
	, m_23(0)
	, m_31(0)
	, m_32(0)
	, m_33(0)
	, m_output(0)
{

}

CDlgTest7::~CDlgTest7()
{
}

void CDlgTest7::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_11);
	DDX_Text(pDX, IDC_EDIT2, m_12);
	DDX_Text(pDX, IDC_EDIT5, m_13);
	DDX_Text(pDX, IDC_EDIT4, m_21);
	DDX_Text(pDX, IDC_EDIT3, m_22);
	DDX_Text(pDX, IDC_EDIT6, m_23);
	DDX_Text(pDX, IDC_EDIT8, m_31);
	DDX_Text(pDX, IDC_EDIT7, m_32);
	DDX_Text(pDX, IDC_EDIT9, m_33);
	DDX_Text(pDX, IDC_EDIT10, m_output);
}


BEGIN_MESSAGE_MAP(CDlgTest7, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON2, &CDlgTest7::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest7::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON3, &CDlgTest7::OnBnClickedButton3)
END_MESSAGE_MAP()


// CDlgTest7 �T���B�z�`��


void CDlgTest7::OnBnClickedButton2()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	srand(time(NULL));
	UpdateData(TRUE);

	m_11 = rand() % 2;
	m_12 = rand() % 2;
	m_13 = rand() % 2;
	m_21 = rand() % 2;
	m_22 = rand() % 2;
	m_23 = rand() % 2;
	m_31 = rand() % 2;
	m_32 = rand() % 2;
	m_33 = rand() % 2;

	UpdateData(FALSE);
}


void CDlgTest7::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	int count = 0;
	//��C
	if (m_11 == 0 && m_12 == 0 && m_13 == 0)
		count++;
	if (m_21 == 0 && m_22 == 0 && m_23 == 0)
		count++;
	if (m_31 == 0 && m_32 == 0 && m_33 == 0)
		count++;
	//����
	if (m_11 == 0 && m_21 == 0 && m_31 == 0)
		count++;
	if (m_12 == 0 && m_22 == 0 && m_32 == 0)
		count++;
	if (m_13 == 0 && m_23 == 0 && m_33 == 0)
		count++;
	//�צV
	if (m_11 == 0 && m_22 == 0 && m_33 == 0)
		count++;
	if (m_31 == 0 && m_22 == 0 && m_13 == 0)
		count++;

	m_output = count;

	UpdateData(FALSE);
}


void CDlgTest7::OnBnClickedButton3()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	srand(time(NULL));

	int t = 0, f = 0;
	if (m_11 == 1)
		t += 1;
	else
		f += 1;
	if (m_12 == 1)
		t += 1;
	else
		f += 1;
	if (m_13 == 1)
		t += 1;
	else
		f += 1;
	if (m_21 == 1)
		t += 1;
	else
		f += 1;
	if (m_22 == 1)
		t += 1;
	else
		f += 1;
	if (m_23 == 1)
		t += 1;
	else
		f += 1;
	if (m_31 == 1)
		t += 1;
	else
		f += 1;
	if (m_32 == 1)
		t += 1;
	else
		f += 1;
	if (m_33 == 1)
		t += 1;
	else
		f += 1;

	if (t > f) 
	{
		CDialogEx::OnCancel();
	}
	else
	{
		m_11 = rand() % 2;
		m_12 = rand() % 2;
		m_13 = rand() % 2;
		m_21 = rand() % 2;
		m_22 = rand() % 2;
		m_23 = rand() % 2;
		m_31 = rand() % 2;
		m_32 = rand() % 2;
		m_33 = rand() % 2;
	}

	UpdateData(FALSE);
}
