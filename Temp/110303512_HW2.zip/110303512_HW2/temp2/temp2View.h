
// temp2View.h : Ctemp2View ���O������
//

#pragma once


class Ctemp2View : public CView
{
protected: // �ȱq�ǦC�ƫإ�
	Ctemp2View();
	DECLARE_DYNCREATE(Ctemp2View)

// �ݩ�
public:
	Ctemp2Doc* GetDocument() const;

// �@�~
public:

// �мg
public:
	virtual void OnDraw(CDC* pDC);  // �мg�H�yø���˵�
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// �{���X��@
public:
	virtual ~Ctemp2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ͪ��T�������禡
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // temp2View.cpp ������������
inline Ctemp2Doc* Ctemp2View::GetDocument() const
   { return reinterpret_cast<Ctemp2Doc*>(m_pDocument); }
#endif

