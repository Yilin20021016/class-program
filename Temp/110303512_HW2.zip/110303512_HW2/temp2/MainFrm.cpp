
// MainFrm.cpp : CMainFrame ���O����@
//

#include "stdafx.h"
#include "temp2.h"

#include "MainFrm.h"
#include "math.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWndEx)

const int  iMaxUserToolbars = 10;
const UINT uiFirstUserToolBarId = AFX_IDW_CONTROLBAR_FIRST + 40;
const UINT uiLastUserToolBarId = uiFirstUserToolBarId + iMaxUserToolbars - 1;

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWndEx)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_CUSTOMIZE, &CMainFrame::OnViewCustomize)
	ON_REGISTERED_MESSAGE(AFX_WM_CREATETOOLBAR, &CMainFrame::OnToolbarCreateNew)
	ON_COMMAND_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnApplicationLook)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnUpdateApplicationLook)
	ON_WM_SETTINGCHANGE()
	ON_COMMAND(IDD_EX1, &CMainFrame::OnEx1)
	ON_COMMAND(IDD_EX2, &CMainFrame::OnEx2)
	ON_COMMAND(IDD_EX3, &CMainFrame::OnEx3)
	ON_COMMAND(IDD_EX4, &CMainFrame::OnEx4)
	ON_COMMAND(IDD_EX5, &CMainFrame::OnEx5)
	ON_COMMAND(IDD_EX6, &CMainFrame::OnEx6)
	ON_COMMAND(IDD_EX7, &CMainFrame::OnEx7)
	ON_COMMAND(IDD_EX8, &CMainFrame::OnEx8)
	ON_COMMAND(IDD_EX9, &CMainFrame::OnEx9)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // ���A�C���ܾ�
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

// CMainFrame �غc/�Ѻc

CMainFrame::CMainFrame()
{
	// TODO: �b���[�J������l�Ƶ{���X
	theApp.m_nAppLook = theApp.GetInt(_T("ApplicationLook"), ID_VIEW_APPLOOK_VS_2008);
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	BOOL bNameValid;

	if (!m_wndMenuBar.Create(this))
	{
		TRACE0("�L�k�إߥ\����C\n");
		return -1;      // �L�k�إ�
	}

	m_wndMenuBar.SetPaneStyle(m_wndMenuBar.GetPaneStyle() | CBRS_SIZE_DYNAMIC | CBRS_TOOLTIPS | CBRS_FLYBY);

	// ����\����C�b�ҥήɨ��o�J�I
	CMFCPopupMenu::SetForceMenuFocus(FALSE);

	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(theApp.m_bHiColorIcons ? IDR_MAINFRAME_256 : IDR_MAINFRAME))
	{
		TRACE0("�L�k�إߤu��C\n");
		return -1;      // �L�k�إ�
	}

	CString strToolBarName;
	bNameValid = strToolBarName.LoadString(IDS_TOOLBAR_STANDARD);
	ASSERT(bNameValid);
	m_wndToolBar.SetWindowText(strToolBarName);

	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);
	m_wndToolBar.EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);

	// ���\�ϥΪ̩w�q���u��C�@�~: 
	InitUserToolbars(NULL, uiFirstUserToolBarId, uiLastUserToolBarId);

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("�L�k�إߪ��A�C\n");
		return -1;      // �L�k�إ�
	}
	m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT));

	// TODO: �p�G���Ʊ�u��C�M�\����C���i���n�A�ЧR���o 5 ��
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndMenuBar);
	DockPane(&m_wndToolBar);


	// �ҥ� Visual Studio 2005 �˦����n�����欰
	CDockingManager::SetDockingMode(DT_SMART);
	// �ҥ� Visual Studio 2005 �˦����n�����۰����æ欰
	EnableAutoHidePanes(CBRS_ALIGN_ANY);

	// ���J�\������ؼv�� (����b����зǤu��C�W): 
	CMFCToolBar::AddToolBarForImageCollection(IDR_MENU_IMAGES, theApp.m_bHiColorIcons ? IDB_MENU_IMAGES_24 : 0);

	// �إ߰��n����
	if (!CreateDockingWindows())
	{
		TRACE0("�L�k�إ߰��n����\n");
		return -1;
	}

	m_wndFileView.EnableDocking(CBRS_ALIGN_ANY);
	m_wndClassView.EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndFileView);
	CDockablePane* pTabbedBar = NULL;
	m_wndClassView.AttachToTabWnd(&m_wndFileView, DM_SHOW, TRUE, &pTabbedBar);
	m_wndOutput.EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndOutput);
	m_wndProperties.EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndProperties);

	// �ھګ���ȳ]�w��ı�ƺ޲z���M�˦�
	OnApplicationLook(theApp.m_nAppLook);

	// �ҥΤu��C�M���n�����\������N
	EnablePaneMenu(TRUE, ID_VIEW_CUSTOMIZE, strCustomize, ID_VIEW_TOOLBAR);

	// �ҥΧֳt (Alt+�즲) �u��C�ۭq
	CMFCToolBar::EnableQuickCustomization();

	if (CMFCToolBar::GetUserImages() == NULL)
	{
		// ���J�ϥΪ̩w�q���u��C�v��
		if (m_UserImages.Load(_T(".\\UserImages.bmp")))
		{
			CMFCToolBar::SetUserImages(&m_UserImages);
		}
	}

	// �ҥΥ\����ӤH�� (�̪�ϥΪ��R�O)
	// TODO: �w�q�z�ۤv���򥻩R�O�A�T�w�C�ӤU�Ԧ��\������ܤ֦��@�Ӱ򥻩R�O�C
	CList<UINT, UINT> lstBasicCommands;

	lstBasicCommands.AddTail(ID_FILE_NEW);
	lstBasicCommands.AddTail(ID_FILE_OPEN);
	lstBasicCommands.AddTail(ID_FILE_SAVE);
	lstBasicCommands.AddTail(ID_FILE_PRINT);
	lstBasicCommands.AddTail(ID_APP_EXIT);
	lstBasicCommands.AddTail(ID_EDIT_CUT);
	lstBasicCommands.AddTail(ID_EDIT_PASTE);
	lstBasicCommands.AddTail(ID_EDIT_UNDO);
	lstBasicCommands.AddTail(ID_APP_ABOUT);
	lstBasicCommands.AddTail(ID_VIEW_STATUS_BAR);
	lstBasicCommands.AddTail(ID_VIEW_TOOLBAR);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2003);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_VS_2005);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_BLUE);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_SILVER);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_BLACK);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_AQUA);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_WINDOWS_7);
	lstBasicCommands.AddTail(ID_SORTING_SORTALPHABETIC);
	lstBasicCommands.AddTail(ID_SORTING_SORTBYTYPE);
	lstBasicCommands.AddTail(ID_SORTING_SORTBYACCESS);
	lstBasicCommands.AddTail(ID_SORTING_GROUPBYTYPE);

	CMFCToolBar::SetBasicCommands(lstBasicCommands);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWndEx::PreCreateWindow(cs) )
		return FALSE;
	// TODO: �b���g�ѭק� CREATESTRUCT cs 
	// �F��ק�������O�μ˦����ت�

	return TRUE;
}

BOOL CMainFrame::CreateDockingWindows()
{
	BOOL bNameValid;

	// �إ����O�˵�
	CString strClassView;
	bNameValid = strClassView.LoadString(IDS_CLASS_VIEW);
	ASSERT(bNameValid);
	if (!m_wndClassView.Create(strClassView, this, CRect(0, 0, 200, 200), TRUE, ID_VIEW_CLASSVIEW, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_LEFT | CBRS_FLOAT_MULTI))
	{
		TRACE0("�L�k�إ� [���O�˵�] ����\n");
		return FALSE; // �L�k�إ�
	}

	// �إ��ɮ��˵�
	CString strFileView;
	bNameValid = strFileView.LoadString(IDS_FILE_VIEW);
	ASSERT(bNameValid);
	if (!m_wndFileView.Create(strFileView, this, CRect(0, 0, 200, 200), TRUE, ID_VIEW_FILEVIEW, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_LEFT| CBRS_FLOAT_MULTI))
	{
		TRACE0("�L�k�إ� [�ɮ��˵�] ����\n");
		return FALSE; // �L�k�إ�
	}

	// �إ߿�X����
	CString strOutputWnd;
	bNameValid = strOutputWnd.LoadString(IDS_OUTPUT_WND);
	ASSERT(bNameValid);
	if (!m_wndOutput.Create(strOutputWnd, this, CRect(0, 0, 100, 100), TRUE, ID_VIEW_OUTPUTWND, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_BOTTOM | CBRS_FLOAT_MULTI))
	{
		TRACE0("�L�k�إ� [��X] ����\n");
		return FALSE; // �L�k�إ�
	}

	// �إ��ݩʵ���
	CString strPropertiesWnd;
	bNameValid = strPropertiesWnd.LoadString(IDS_PROPERTIES_WND);
	ASSERT(bNameValid);
	if (!m_wndProperties.Create(strPropertiesWnd, this, CRect(0, 0, 200, 200), TRUE, ID_VIEW_PROPERTIESWND, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_RIGHT | CBRS_FLOAT_MULTI))
	{
		TRACE0("�L�k�إ� [�ݩ�] ����\n");
		return FALSE; // �L�k�إ�
	}

	SetDockingWindowIcons(theApp.m_bHiColorIcons);
	return TRUE;
}

void CMainFrame::SetDockingWindowIcons(BOOL bHiColorIcons)
{
	HICON hFileViewIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(bHiColorIcons ? IDI_FILE_VIEW_HC : IDI_FILE_VIEW), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndFileView.SetIcon(hFileViewIcon, FALSE);

	HICON hClassViewIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(bHiColorIcons ? IDI_CLASS_VIEW_HC : IDI_CLASS_VIEW), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndClassView.SetIcon(hClassViewIcon, FALSE);

	HICON hOutputBarIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(bHiColorIcons ? IDI_OUTPUT_WND_HC : IDI_OUTPUT_WND), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndOutput.SetIcon(hOutputBarIcon, FALSE);

	HICON hPropertiesBarIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(bHiColorIcons ? IDI_PROPERTIES_WND_HC : IDI_PROPERTIES_WND), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndProperties.SetIcon(hPropertiesBarIcon, FALSE);

}

// CMainFrame �E�_

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWndEx::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWndEx::Dump(dc);
}
#endif //_DEBUG


// CMainFrame �T���B�z�`��

void CMainFrame::OnViewCustomize()
{
	CMFCToolBarsCustomizeDialog* pDlgCust = new CMFCToolBarsCustomizeDialog(this, TRUE /* ���y�\��� */);
	pDlgCust->EnableUserDefinedToolbars();
	pDlgCust->Create();
}

LRESULT CMainFrame::OnToolbarCreateNew(WPARAM wp,LPARAM lp)
{
	LRESULT lres = CFrameWndEx::OnToolbarCreateNew(wp,lp);
	if (lres == 0)
	{
		return 0;
	}

	CMFCToolBar* pUserToolbar = (CMFCToolBar*)lres;
	ASSERT_VALID(pUserToolbar);

	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
	return lres;
}

void CMainFrame::OnApplicationLook(UINT id)
{
	CWaitCursor wait;

	theApp.m_nAppLook = id;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_WIN_2000:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManager));
		break;

	case ID_VIEW_APPLOOK_OFF_XP:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOfficeXP));
		break;

	case ID_VIEW_APPLOOK_WIN_XP:
		CMFCVisualManagerWindows::m_b3DTabsXPTheme = TRUE;
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));
		break;

	case ID_VIEW_APPLOOK_OFF_2003:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2003));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_VS_2005:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2005));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_VS_2008:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2008));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_WINDOWS_7:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows7));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	default:
		switch (theApp.m_nAppLook)
		{
		case ID_VIEW_APPLOOK_OFF_2007_BLUE:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_LunaBlue);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_BLACK:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_ObsidianBlack);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_SILVER:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Silver);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_AQUA:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Aqua);
			break;
		}

		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2007));
		CDockingManager::SetDockingMode(DT_SMART);
	}

	m_wndOutput.UpdateFonts();
	RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE | RDW_UPDATENOW | RDW_FRAME | RDW_ERASE);

	theApp.WriteInt(_T("ApplicationLook"), theApp.m_nAppLook);
}

void CMainFrame::OnUpdateApplicationLook(CCmdUI* pCmdUI)
{
	pCmdUI->SetRadio(theApp.m_nAppLook == pCmdUI->m_nID);
}


BOOL CMainFrame::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd* pParentWnd, CCreateContext* pContext) 
{
	// �����O�q�ƹ�ڧ@�~

	if (!CFrameWndEx::LoadFrame(nIDResource, dwDefaultStyle, pParentWnd, pContext))
	{
		return FALSE;
	}


	// �ҥΩҦ��ϥΪ̤u��C���ۭq���s
	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	for (int i = 0; i < iMaxUserToolbars; i ++)
	{
		CMFCToolBar* pUserToolbar = GetUserToolBarByIndex(i);
		if (pUserToolbar != NULL)
		{
			pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
		}
	}

	return TRUE;
}


void CMainFrame::OnSettingChange(UINT uFlags, LPCTSTR lpszSection)
{
	CFrameWndEx::OnSettingChange(uFlags, lpszSection);
	m_wndOutput.UpdateFonts();
}


void CMainFrame::OnEx1()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	int i;
	CString o2;
	i = 0;
	o2.Format(_T("i=%d"),i);
	AfxMessageBox(o2);
	i = 4;
	i++;//i=i+1
	o2.Format(_T("i++,i=%d"), i);
	AfxMessageBox(o2);
	i = 7;
	i += 2;//i=i+2
	o2.Format(_T("i+=2,i=%d"), i);
	AfxMessageBox(o2);
	i = 6;
	i--;//i=i-1
	o2.Format(_T("i--,i=%d"), i);
	AfxMessageBox(o2);
	i = 4;
	i -= 3;//i=i-3
	o2.Format(_T("i-=3,i=%d"), i);
	AfxMessageBox(o2);
}


void CMainFrame::OnEx2()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	double n, m;
	int TreeCount;

	n = 100.5;
	m = 3.5;
	double double_Q;
	int int_Q;
	double_Q = n / m;    //12.345
	int_Q = (int)(n / m);//12(�j��O�ഫ) 

	//Method 1
	CString outstring;
	if (double_Q-int_Q>0) {
		outstring = _T("����㰣");
	}
	else {
		outstring = _T("�i�H�㰣");
	}
	AfxMessageBox(outstring);

	//Method 2
	//?(true�ɰ���):(false�ɰ���)
	/*
	CString outstring=(double_Q-int_Q>0)
	?(_T("����㰣")):(_T("�i�H�㰣"))
	*/
	
	CString outstring2;
	if (double_Q - int_Q>0) {
		TreeCount = int_Q + 2;
	}
	else {
		TreeCount = int_Q + 1;
	}
	outstring2.Format(_T("n=%.2f, m=%g, TreeNum=%d"), n, m, TreeCount);
	AfxMessageBox(outstring2);
}


void CMainFrame::OnEx3()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	int a, b;

	a = 4;
	b = sqrt(a);

	CString string;
	string.Format(_T("%d ���}�ڸ��� %d"), a, b);
	AfxMessageBox(string);
}


void CMainFrame::OnEx4()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	double x1, y1;//Point 1
	double x2, y2;//Point 2
	double distance_2, distance;

	//Point 1=(0,0)
	x1 = 0;
	y1 = 0;
	//Point 2=(1,1)
	x2 = 1;
	y2 = 1;

	distance_2 = (x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2);
	distance = sqrt(distance_2);

	FILE *fp;
	fopen_s(&fp, "..\\110303512_HW2_Ex4.txt","w");//fopen_s�O�s�����Ϊk
	fprintf(fp, "x1=%f, y1=%f\n",x1,y1);
	fprintf(fp, "x2=%f, y2=%f\n", x2, y2);
	fprintf(fp, "Distance=%f", distance);
	fclose(fp);

	CString file = _T("..\\110303512_HW2_Ex4.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx5()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	double a,b;
	int c;
	a = 25.5;
	b = 2000;
	c = b / a;

	CString o2;
	o2.Format(_T("Total money we have:%f.  Each apple costs:%f.  Max number of apples we can buy:%d."), b, a, c);
	AfxMessageBox(o2);

	FILE *fp;
	fopen_s(&fp, "..\\110303512_HW2_Ex5.txt", "w");
	fprintf(fp, "The cost of each apple:%f\nTotal dollars we have:%f\nNumber of apples we can buy:%d", a, b, c);
	fclose(fp);

	CString file = _T("..\\110303512_HW2_Ex5.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx6()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	int a, b, c, d;

	a = 10;
	b = 3;

	c = a / b;
	d = a % b;

	FILE *fp;
	fopen_s(&fp, "..\\110303512_HW2_Ex6.txt", "w");
	fprintf(fp, "%d���H%d���Ӭ�%d, �l�Ƭ�%d", a, b, c, d);
	fclose(fp);

	CString file = _T("..\\110303512_HW2_Ex6.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx7()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	int a0 = 2, r = 2, n = 10;
	double an, sum;
	an = a0*pow(r, n - 1);
	sum = a0*(1 - pow(r, n)) / (1 - r);
	FILE *fp;
	fopen_s(&fp, "..\\110303512_HW2_Ex7.txt", "w");
	fprintf(fp, "a0=%d  r=%d  n=%d\nan=%g  sum=%g", a0, r, n, an, sum);
	fclose(fp);

	CString file = _T("..\\110303512_HW2_Ex7.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx8()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X	
	int i, sum1 = 0, sum2 = 0;
	int year = 2020, month = 7, day = 21;
	int a[12] = { 31,28,31,30,31,30,31,31,30,31,30,31 };
	int b[12] = { 31,29,31,30,31,30,31,31,30,31,30,31 };
	if ((year%4==0&&year%4!=0)||year%4==0)
	{
		for(i=0;i<(month-1);i++)
		{
			sum1 += b[i];
		}
	}
	else
	{
		for (i = 0; i<(month - 1); i++)
		{
			sum1 += a[i];
		}
	}
	sum1 += day;

	year = 2021, month = 10, day = 10;
	if ((year % 4 == 0 && year % 4 != 0) || year % 4 == 0)
	{
		for (i = 0; i<(month - 1); i++)
		{
			sum2 += b[i];
		}
	}
	else
	{
		for (i = 0; i<(month - 1); i++)
		{
			sum2 += a[i];
		}
	}
	sum2 += day;

	FILE *fp;
	fopen_s(&fp, "..\\110303512_HW2_Ex8.txt", "w");
	fprintf(fp, "(1)2020�~7��21��O�Ӧ~��%d��\n(2)2021�~10��10��O�Ӧ~��%d��", sum1, sum2);
	fclose(fp);

	CString file = _T("..\\110303512_HW2_Ex8.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx9()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\110303512_HW2_Ex9.txt", "w");
	int i,remainder;
	fprintf(fp, "Factor\tremainder\n");
	for (i = 2; i < 12; i++) 
	{
		fprintf(fp, "%d\t", i);
		remainder = 12 % i;
		fprintf(fp, "%d\n", remainder);
	}
	fclose(fp);
	CString file = _T("..\\110303512_HW2_Ex9.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}
