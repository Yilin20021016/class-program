// DlgTest2.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_Excercise.h"
#include "DlgTest2.h"
#include "afxdialogex.h"


// CDlgTest2 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest2, CDialogEx)

CDlgTest2::CDlgTest2(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG2, pParent)
	, m_input1(0)
	, m_input2(0)
	, m_output(0)
	, m_check(0)
{

}

CDlgTest2::~CDlgTest2()
{
}

void CDlgTest2::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_input1);
	DDX_Text(pDX, IDC_EDIT2, m_input2);
	DDX_Text(pDX, IDC_EDIT3, m_output);
	DDX_Radio(pDX, IDC_RADIO1, m_check);
}


BEGIN_MESSAGE_MAP(CDlgTest2, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest2::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CDlgTest2::OnBnClickedButton2)
END_MESSAGE_MAP()


// CDlgTest2 �T���B�z�`��


void CDlgTest2::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);

	if (m_check == 0) 
	{
		m_output = m_input1 + m_input2;
	}
	else if (m_check == 1) 
	{
		m_output = m_input1 - m_input2;
	}

	UpdateData(FALSE);
}


void CDlgTest2::OnBnClickedButton2()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	m_input1 = 0;
	m_input2 = 0;
	m_output = 0;
	UpdateData(FALSE);
}
