// DlgTest1.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_Excercise.h"
#include "DlgTest1.h"
#include "afxdialogex.h"


// CDlgTest1 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest1, CDialogEx)

CDlgTest1::CDlgTest1(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, m_input(0)
	, m_output(0)
	, m_hr(0)
	, m_min(0)
	, m_sec(0)
	, m_change(FALSE)
{

}

CDlgTest1::~CDlgTest1()
{
}

void CDlgTest1::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT5, m_input);
	DDX_Text(pDX, IDC_EDIT4, m_output);
	DDX_Text(pDX, IDC_EDIT1, m_hr);
	DDX_Text(pDX, IDC_EDIT2, m_min);
	DDX_Text(pDX, IDC_EDIT3, m_sec);
	DDX_Check(pDX, IDC_CHECK1, m_change);
}


BEGIN_MESSAGE_MAP(CDlgTest1, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest1::OnBnClickedButton1)
END_MESSAGE_MAP()


// CDlgTest1 �T���B�z�`��


void CDlgTest1::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);

	if (m_change) 
	{
		m_sec = m_input % 60;
		m_min = (m_input / 60) % 60;
		m_hr = m_input / 3600;
	}
	else 
	{
		m_output = m_input;
	}
	UpdateData(FALSE);
}
