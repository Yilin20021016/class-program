// DlgTest3.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_Excercise.h"
#include "DlgTest3.h"
#include "afxdialogex.h"



// CDlgTest3 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest3, CDialogEx)

CDlgTest3::CDlgTest3(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG3, pParent)
	, m_name(_T(""))
	, m_num(0)
	, m_total(0)
{

}

CDlgTest3::~CDlgTest3()
{
}

void CDlgTest3::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT2, m_name);
	DDX_Text(pDX, IDC_EDIT3, m_num);
	DDX_Text(pDX, IDC_EDIT1, m_total);
}


BEGIN_MESSAGE_MAP(CDlgTest3, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest3::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CDlgTest3::OnBnClickedButton2)
END_MESSAGE_MAP()


// CDlgTest3 �T���B�z�`��


void CDlgTest3::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);

	m_total = m_num * 100;

	Order person;

	person.Name = m_name;
	person.Num = m_num;
	person.Total = m_total;

	list.push_back(person);

	UpdateData(FALSE);
}


void CDlgTest3::OnBnClickedButton2()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	CString title=_T("�q�ʤH\t�M��\t�`��\n");
	CString o2,str=_T("");
	for (int i = 0; i < list.size(); i++)
	{
		o2.Format(_T("%s\t%d\t%d\n"), list[i].Name, list[i].Num, list[i].Total);
		str += o2;
	}
	AfxMessageBox(title + str);
}

Order::Order()
{
	Name = _T("");
	Num = 0;
	Total = 0;
}
