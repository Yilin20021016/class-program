//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ͪ� Include �ɮסC
// �� 110303512_HW1.rc �ϥ�
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_My110303512_HW1TYPE         130
#define ID_TEST                         32771
#define IDD_TEST                        32772
#define ID_EX3                          32773
#define IDD_EX3                         32774
#define ID_EX5                          32775
#define IDD_EX5                         32776
#define ID_EX2_EXER                     32777
#define ID_EX2_EXER32778                32778
#define ID_EX4                          32779
#define IDD_EX4                         32780
#define ID_EX                           32781
#define ID_EX8                          32782
#define IDD_EX                          32783
#define IDD_EX8                         32784
#define ID_EX6                          32785
#define ID_EX7                          32786
#define IDD_EX7                         32787
#define ID_EX9                          32788
#define IDD_EX9                         32789
#define IDD_EX2_EXER                    32790
#define IDD_EX2_EXER32778               32791
#define IDD_EX10                        32792
#define IDD_EX11                        32793
#define IDD_EXer_1                      32794
#define IDD_EXer2                       32795

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
