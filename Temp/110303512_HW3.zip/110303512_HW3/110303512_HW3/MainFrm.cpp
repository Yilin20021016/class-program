
// MainFrm.cpp : CMainFrame ���O����@
//

#include "stdafx.h"
#include "110303512_HW3.h"
#include "math.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWndEx)

const int  iMaxUserToolbars = 10;
const UINT uiFirstUserToolBarId = AFX_IDW_CONTROLBAR_FIRST + 40;
const UINT uiLastUserToolBarId = uiFirstUserToolBarId + iMaxUserToolbars - 1;

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWndEx)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_CUSTOMIZE, &CMainFrame::OnViewCustomize)
	ON_REGISTERED_MESSAGE(AFX_WM_CREATETOOLBAR, &CMainFrame::OnToolbarCreateNew)
	ON_COMMAND_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnApplicationLook)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnUpdateApplicationLook)
	ON_WM_SETTINGCHANGE()
	ON_COMMAND(IDD_EX1, &CMainFrame::OnEx1)
	ON_COMMAND(IDD_EX2, &CMainFrame::OnEx2)
	ON_COMMAND(IDD_EX3, &CMainFrame::OnEx3)
	ON_COMMAND(IDD_EX4, &CMainFrame::OnEx4)
	ON_COMMAND(IDD_EX5, &CMainFrame::OnEx5)
	ON_COMMAND(IDD_EX6, &CMainFrame::OnEx6)
	ON_COMMAND(IDD_EX7, &CMainFrame::OnEx7)
	ON_COMMAND(IDD_EX8, &CMainFrame::OnEx8)
	ON_COMMAND(IDD_EX9, &CMainFrame::OnEx9)
	ON_COMMAND(IDD_EX10, &CMainFrame::OnEx10)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // ���A�C���ܾ�
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

// CMainFrame �غc/�Ѻc

CMainFrame::CMainFrame()
{
	// TODO: �b���[�J������l�Ƶ{���X
	theApp.m_nAppLook = theApp.GetInt(_T("ApplicationLook"), ID_VIEW_APPLOOK_VS_2008);
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	BOOL bNameValid;

	if (!m_wndMenuBar.Create(this))
	{
		TRACE0("�L�k�إߥ\����C\n");
		return -1;      // �L�k�إ�
	}

	m_wndMenuBar.SetPaneStyle(m_wndMenuBar.GetPaneStyle() | CBRS_SIZE_DYNAMIC | CBRS_TOOLTIPS | CBRS_FLYBY);

	// ����\����C�b�ҥήɨ��o�J�I
	CMFCPopupMenu::SetForceMenuFocus(FALSE);

	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(theApp.m_bHiColorIcons ? IDR_MAINFRAME_256 : IDR_MAINFRAME))
	{
		TRACE0("�L�k�إߤu��C\n");
		return -1;      // �L�k�إ�
	}

	CString strToolBarName;
	bNameValid = strToolBarName.LoadString(IDS_TOOLBAR_STANDARD);
	ASSERT(bNameValid);
	m_wndToolBar.SetWindowText(strToolBarName);

	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);
	m_wndToolBar.EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);

	// ���\�ϥΪ̩w�q���u��C�@�~: 
	InitUserToolbars(NULL, uiFirstUserToolBarId, uiLastUserToolBarId);

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("�L�k�إߪ��A�C\n");
		return -1;      // �L�k�إ�
	}
	m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT));

	// TODO: �p�G���Ʊ�u��C�M�\����C���i���n�A�ЧR���o 5 ��
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndMenuBar);
	DockPane(&m_wndToolBar);


	// �ҥ� Visual Studio 2005 �˦����n�����欰
	CDockingManager::SetDockingMode(DT_SMART);
	// �ҥ� Visual Studio 2005 �˦����n�����۰����æ欰
	EnableAutoHidePanes(CBRS_ALIGN_ANY);

	// ���J�\������ؼv�� (����b����зǤu��C�W): 
	CMFCToolBar::AddToolBarForImageCollection(IDR_MENU_IMAGES, theApp.m_bHiColorIcons ? IDB_MENU_IMAGES_24 : 0);

	// �إ߰��n����
	if (!CreateDockingWindows())
	{
		TRACE0("�L�k�إ߰��n����\n");
		return -1;
	}

	m_wndFileView.EnableDocking(CBRS_ALIGN_ANY);
	m_wndClassView.EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndFileView);
	CDockablePane* pTabbedBar = NULL;
	m_wndClassView.AttachToTabWnd(&m_wndFileView, DM_SHOW, TRUE, &pTabbedBar);
	m_wndOutput.EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndOutput);
	m_wndProperties.EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndProperties);

	// �ھګ���ȳ]�w��ı�ƺ޲z���M�˦�
	OnApplicationLook(theApp.m_nAppLook);

	// �ҥΤu��C�M���n�����\������N
	EnablePaneMenu(TRUE, ID_VIEW_CUSTOMIZE, strCustomize, ID_VIEW_TOOLBAR);

	// �ҥΧֳt (Alt+�즲) �u��C�ۭq
	CMFCToolBar::EnableQuickCustomization();

	if (CMFCToolBar::GetUserImages() == NULL)
	{
		// ���J�ϥΪ̩w�q���u��C�v��
		if (m_UserImages.Load(_T(".\\UserImages.bmp")))
		{
			CMFCToolBar::SetUserImages(&m_UserImages);
		}
	}

	// �ҥΥ\����ӤH�� (�̪�ϥΪ��R�O)
	// TODO: �w�q�z�ۤv���򥻩R�O�A�T�w�C�ӤU�Ԧ��\������ܤ֦��@�Ӱ򥻩R�O�C
	CList<UINT, UINT> lstBasicCommands;

	lstBasicCommands.AddTail(ID_FILE_NEW);
	lstBasicCommands.AddTail(ID_FILE_OPEN);
	lstBasicCommands.AddTail(ID_FILE_SAVE);
	lstBasicCommands.AddTail(ID_FILE_PRINT);
	lstBasicCommands.AddTail(ID_APP_EXIT);
	lstBasicCommands.AddTail(ID_EDIT_CUT);
	lstBasicCommands.AddTail(ID_EDIT_PASTE);
	lstBasicCommands.AddTail(ID_EDIT_UNDO);
	lstBasicCommands.AddTail(ID_APP_ABOUT);
	lstBasicCommands.AddTail(ID_VIEW_STATUS_BAR);
	lstBasicCommands.AddTail(ID_VIEW_TOOLBAR);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2003);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_VS_2005);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_BLUE);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_SILVER);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_BLACK);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_AQUA);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_WINDOWS_7);
	lstBasicCommands.AddTail(ID_SORTING_SORTALPHABETIC);
	lstBasicCommands.AddTail(ID_SORTING_SORTBYTYPE);
	lstBasicCommands.AddTail(ID_SORTING_SORTBYACCESS);
	lstBasicCommands.AddTail(ID_SORTING_GROUPBYTYPE);

	CMFCToolBar::SetBasicCommands(lstBasicCommands);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWndEx::PreCreateWindow(cs) )
		return FALSE;
	// TODO: �b���g�ѭק� CREATESTRUCT cs 
	// �F��ק�������O�μ˦����ت�

	return TRUE;
}

BOOL CMainFrame::CreateDockingWindows()
{
	BOOL bNameValid;

	// �إ����O�˵�
	CString strClassView;
	bNameValid = strClassView.LoadString(IDS_CLASS_VIEW);
	ASSERT(bNameValid);
	if (!m_wndClassView.Create(strClassView, this, CRect(0, 0, 200, 200), TRUE, ID_VIEW_CLASSVIEW, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_LEFT | CBRS_FLOAT_MULTI))
	{
		TRACE0("�L�k�إ� [���O�˵�] ����\n");
		return FALSE; // �L�k�إ�
	}

	// �إ��ɮ��˵�
	CString strFileView;
	bNameValid = strFileView.LoadString(IDS_FILE_VIEW);
	ASSERT(bNameValid);
	if (!m_wndFileView.Create(strFileView, this, CRect(0, 0, 200, 200), TRUE, ID_VIEW_FILEVIEW, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_LEFT| CBRS_FLOAT_MULTI))
	{
		TRACE0("�L�k�إ� [�ɮ��˵�] ����\n");
		return FALSE; // �L�k�إ�
	}

	// �إ߿�X����
	CString strOutputWnd;
	bNameValid = strOutputWnd.LoadString(IDS_OUTPUT_WND);
	ASSERT(bNameValid);
	if (!m_wndOutput.Create(strOutputWnd, this, CRect(0, 0, 100, 100), TRUE, ID_VIEW_OUTPUTWND, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_BOTTOM | CBRS_FLOAT_MULTI))
	{
		TRACE0("�L�k�إ� [��X] ����\n");
		return FALSE; // �L�k�إ�
	}

	// �إ��ݩʵ���
	CString strPropertiesWnd;
	bNameValid = strPropertiesWnd.LoadString(IDS_PROPERTIES_WND);
	ASSERT(bNameValid);
	if (!m_wndProperties.Create(strPropertiesWnd, this, CRect(0, 0, 200, 200), TRUE, ID_VIEW_PROPERTIESWND, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_RIGHT | CBRS_FLOAT_MULTI))
	{
		TRACE0("�L�k�إ� [�ݩ�] ����\n");
		return FALSE; // �L�k�إ�
	}

	SetDockingWindowIcons(theApp.m_bHiColorIcons);
	return TRUE;
}

void CMainFrame::SetDockingWindowIcons(BOOL bHiColorIcons)
{
	HICON hFileViewIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(bHiColorIcons ? IDI_FILE_VIEW_HC : IDI_FILE_VIEW), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndFileView.SetIcon(hFileViewIcon, FALSE);

	HICON hClassViewIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(bHiColorIcons ? IDI_CLASS_VIEW_HC : IDI_CLASS_VIEW), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndClassView.SetIcon(hClassViewIcon, FALSE);

	HICON hOutputBarIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(bHiColorIcons ? IDI_OUTPUT_WND_HC : IDI_OUTPUT_WND), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndOutput.SetIcon(hOutputBarIcon, FALSE);

	HICON hPropertiesBarIcon = (HICON) ::LoadImage(::AfxGetResourceHandle(), MAKEINTRESOURCE(bHiColorIcons ? IDI_PROPERTIES_WND_HC : IDI_PROPERTIES_WND), IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), 0);
	m_wndProperties.SetIcon(hPropertiesBarIcon, FALSE);

}

// CMainFrame �E�_

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWndEx::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWndEx::Dump(dc);
}
#endif //_DEBUG


// CMainFrame �T���B�z�`��

void CMainFrame::OnViewCustomize()
{
	CMFCToolBarsCustomizeDialog* pDlgCust = new CMFCToolBarsCustomizeDialog(this, TRUE /* ���y�\��� */);
	pDlgCust->EnableUserDefinedToolbars();
	pDlgCust->Create();
}

LRESULT CMainFrame::OnToolbarCreateNew(WPARAM wp,LPARAM lp)
{
	LRESULT lres = CFrameWndEx::OnToolbarCreateNew(wp,lp);
	if (lres == 0)
	{
		return 0;
	}

	CMFCToolBar* pUserToolbar = (CMFCToolBar*)lres;
	ASSERT_VALID(pUserToolbar);

	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
	return lres;
}

void CMainFrame::OnApplicationLook(UINT id)
{
	CWaitCursor wait;

	theApp.m_nAppLook = id;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_WIN_2000:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManager));
		break;

	case ID_VIEW_APPLOOK_OFF_XP:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOfficeXP));
		break;

	case ID_VIEW_APPLOOK_WIN_XP:
		CMFCVisualManagerWindows::m_b3DTabsXPTheme = TRUE;
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));
		break;

	case ID_VIEW_APPLOOK_OFF_2003:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2003));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_VS_2005:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2005));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_VS_2008:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2008));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_WINDOWS_7:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows7));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	default:
		switch (theApp.m_nAppLook)
		{
		case ID_VIEW_APPLOOK_OFF_2007_BLUE:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_LunaBlue);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_BLACK:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_ObsidianBlack);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_SILVER:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Silver);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_AQUA:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Aqua);
			break;
		}

		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2007));
		CDockingManager::SetDockingMode(DT_SMART);
	}

	m_wndOutput.UpdateFonts();
	RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE | RDW_UPDATENOW | RDW_FRAME | RDW_ERASE);

	theApp.WriteInt(_T("ApplicationLook"), theApp.m_nAppLook);
}

void CMainFrame::OnUpdateApplicationLook(CCmdUI* pCmdUI)
{
	pCmdUI->SetRadio(theApp.m_nAppLook == pCmdUI->m_nID);
}


BOOL CMainFrame::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd* pParentWnd, CCreateContext* pContext) 
{
	// �����O�q�ƹ�ڧ@�~

	if (!CFrameWndEx::LoadFrame(nIDResource, dwDefaultStyle, pParentWnd, pContext))
	{
		return FALSE;
	}


	// �ҥΩҦ��ϥΪ̤u��C���ۭq���s
	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	for (int i = 0; i < iMaxUserToolbars; i ++)
	{
		CMFCToolBar* pUserToolbar = GetUserToolBarByIndex(i);
		if (pUserToolbar != NULL)
		{
			pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
		}
	}

	return TRUE;
}


void CMainFrame::OnSettingChange(UINT uFlags, LPCTSTR lpszSection)
{
	CFrameWndEx::OnSettingChange(uFlags, lpszSection);
	m_wndOutput.UpdateFonts();
}


void CMainFrame::OnEx1()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	CString str;
	str = "This is  my first output";

	FILE *fp;
	fopen_s(&fp, "..\\test1.txt", "w");
	fprintf(fp, "%S\n", str);
	fclose(fp);

	CString file = _T("..\\test1.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);

	//Read txt file
	char term1[10], term2[10], term3[10], term4[10], term5[10];
	fopen_s(&fp, "..\\test1.txt", "r");
	fscanf_s(fp, "%s", &term1, sizeof(term1));
	fscanf_s(fp, "%s", &term2, sizeof(term2));
	fscanf_s(fp, "%s", &term3, sizeof(term3));
	fscanf_s(fp, "%s", &term4, sizeof(term4));
	fscanf_s(fp, "%s", &term5, sizeof(term5));
	fclose(fp);

	CString str_out;
	str_out.Format(_T("%S %S %S %S %S.\n"), term1, term2, term3, term4, term5);
	AfxMessageBox(str_out);
}


void CMainFrame::OnEx2()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	int a1, b1, c1;

	a1 = 1; b1 = 2; c1 = 3;

	FILE *fp;
	fopen_s(&fp, "..\\test2.txt", "w");
	fprintf(fp, "%d %d %d\n", a1, b1, c1);
	fclose(fp);

	CString file = _T("..\\test2.txt", "r");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);

	int a1_r, b1_r, c1_r;
	fopen_s(&fp, "..\\test2.txt", "r");
	fscanf_s(fp, "%d %d %d", &a1_r, &b1_r, &c1_r);
	fclose(fp);

	int sum;
	sum = a1_r + b1_r + c1_r;
	CString str;
	str.Format(_T("sum = %d"), sum);
	AfxMessageBox(str);
}


void CMainFrame::OnEx3()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	CString str;
	str = "This\nis\nmy\nfirst\noutput";

	FILE *fp;
	fopen_s(&fp, "..\\test3.txt", "w");
	fprintf(fp, "%S", str);
	fclose(fp);

	CString file = _T("..\\test3.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);


	char term1[10], term2[10], term3[10], term4[10], term5[10];
	fopen_s(&fp, "..\\test3.txt", "r");
	fscanf_s(fp, "%s", &term1, sizeof(term1));
	fscanf_s(fp, "%s", &term2, sizeof(term2));
	fscanf_s(fp, "%s", &term3, sizeof(term3));
	fscanf_s(fp, "%s", &term4, sizeof(term4));
	fscanf_s(fp, "%s", &term5, sizeof(term5));
	fclose(fp);

	CString str_out;
	str_out.Format(_T("%S\n%S\n%S\n%S\n%S"), term1, term2, term3, term4, term5);
	AfxMessageBox(str_out);
}


void CMainFrame::OnEx4()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	int a1, b1, c1;
	int a2, b2, c2;
	int a3, b3, c3;
	
	a1 = 1; b1 = 2; c1 = 3;
	a2 = 4; b2 = 5; c2 = 6;
	a3 = 7; b3 = 8; c3 = 9;

	FILE *fp;
	fopen_s(&fp, "..\\test4.txt", "w");
	fprintf(fp, "%d %d %d\n", a1, b1, c1);
	fprintf(fp, "%d %d %d\n", a2, b2, c2);
	fprintf(fp, "%d %d %d", a3, b3, c3);
	fclose(fp);

	CString file = _T("..\\test4.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);

	//Read txt file
	int a1_r, b1_r, c1_r;
	int a2_r, b2_r, c2_r;
	int a3_r, b3_r, c3_r;
	fopen_s(&fp, "..\\test4.txt", "r");
	fscanf_s(fp, "%d %d %d", &a1_r, &b1_r, &c1_r);
	fscanf_s(fp, "%d %d %d", &a2_r, &b2_r, &c2_r);
	fscanf_s(fp, "%d %d %d", &a3_r, &b3_r, &c3_r);
	fclose(fp);

	int sum_c1, sum_c2, sum_c3;
	sum_c1 = a1_r + a2_r + a3_r;
	sum_c2 = b1_r + b2_r + b3_r;
	sum_c3 = c1_r + c2_r + c3_r;

	CString str;
	str.Format(_T("column1 = %d, column2 = %d, column3 = %d"), sum_c1, sum_c2, sum_c3);
	AfxMessageBox(str);
}


void CMainFrame::OnEx5()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	CString str = _T("Hello this is exercise 5\n1  2 3");
	FILE *fp;
	fopen_s(&fp, "..\\test5.txt","w");
	fprintf(fp, "%S", str);
	fclose(fp);

	CString file = _T("..\\test5.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx6()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	char term1[10], term2[10], term3[10], term4[10], term5[10];
	fopen_s(&fp, "..\\test1.txt", "r");
	fscanf_s(fp, "%s", &term1, sizeof(term1));
	fscanf_s(fp, "%s", &term2, sizeof(term2));
	fscanf_s(fp, "%s", &term3, sizeof(term3));
	fscanf_s(fp, "%s", &term4, sizeof(term4));
	fscanf_s(fp, "%s", &term5, sizeof(term5));
	fclose(fp);

	CString o2;
	o2.Format(_T("%S %S %S second %S"), term1, term2, term3, term5);
	AfxMessageBox(o2);
}


void CMainFrame::OnEx7()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\test7.txt", "w");
	fprintf(fp, "10\n33\n56\n26\n84\n39\n67\n87\n");
	fclose(fp);

	CString file = _T("..\\test7.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx8()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\test7.txt","r");

	int n1, n2, n3, n4, n5, n6, n7, n8;
	int sum;
	fscanf_s(fp, "%d %d %d %d %d %d %d %d", &n1, &n2, &n3, &n4, &n5, &n6, &n7, &n8);
	fclose(fp);

	sum = n1 + n2 + n3 + n4 + n5 + n6 + n7 + n8;
	CString str;
	str.Format(_T("sum = %d"), sum);
	AfxMessageBox(str);
}


void CMainFrame::OnEx9()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\test1.txt", "a");
	int i,j;
	for (i = 0; i < 9; i++) 
	{
		if(i<=4)
		{
			for (j = 0; j < i+1; j++) 
			{
				fprintf(fp, "%d ", j+1);
			}
		}
		else
		{
			for (j = 0; j < 9-i; j++) 
			{
				fprintf(fp, "%d ", j+1);
			}
		}
		fprintf(fp, "\n");
	}
	fclose(fp);
	CString file = _T("..\\test1.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);

	CString str;
	str.Format(_T("55"));
	AfxMessageBox(str);
}


void CMainFrame::OnEx10()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\input10.txt", "w");
	fprintf(fp, "0 0\n10 0\n5 5");
	fclose(fp);

	double x1 = 0, y1 = 0;
	double x2 = 10, y2 = 0;
	double x3 = 5, y3 = 5;
	double a, b, c, area, perimeter, gx, gy;
	a = sqrt((x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1));
	b = sqrt((x3 - x2)*(x3 - x2) + (y3 - y2)*(y3 - y2));
	c = sqrt((x1 - x3)*(x1 - x3) + (y1 - y3)*(y1 - y3));
	perimeter = a + b + c;
	double s = 0.5 * perimeter;
	area = sqrt(s*(s - a)*(s - b)*(s - c));
	gx = (x1 + x2 + x3) / 3;
	gy = (y1 + y2 + y3) / 3;

	fopen_s(&fp, "..\\test10.txt", "w");
	fprintf(fp, "x1=%f y1=%f\nx2=%f y2=%f\nx3=%f y3=%f\n", x1, y1, x2, y2, x3, y3);
	fprintf(fp, "area=%g\npermeter=%g\ncenter of gravity=(%g, %g)", area, perimeter, gx, gy);
	fclose(fp);
	CString file = _T("..\\test10.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}
