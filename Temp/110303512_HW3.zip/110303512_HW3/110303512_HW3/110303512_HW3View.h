
// 110303512_HW3View.h : CMy110303512_HW3View ���O������
//

#pragma once


class CMy110303512_HW3View : public CView
{
protected: // �ȱq�ǦC�ƫإ�
	CMy110303512_HW3View();
	DECLARE_DYNCREATE(CMy110303512_HW3View)

// �ݩ�
public:
	CMy110303512_HW3Doc* GetDocument() const;

// �@�~
public:

// �мg
public:
	virtual void OnDraw(CDC* pDC);  // �мg�H�yø���˵�
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// �{���X��@
public:
	virtual ~CMy110303512_HW3View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ���ͪ��T�������禡
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // 110303512_HW3View.cpp ������������
inline CMy110303512_HW3Doc* CMy110303512_HW3View::GetDocument() const
   { return reinterpret_cast<CMy110303512_HW3Doc*>(m_pDocument); }
#endif

