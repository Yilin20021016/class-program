
// MainFrm.cpp : CMainFrame ���O����@
//

#include "stdafx.h"
#include "110303512_HW6.h"

#include "MainFrm.h"
#include <vector>
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWndEx)

const int  iMaxUserToolbars = 10;
const UINT uiFirstUserToolBarId = AFX_IDW_CONTROLBAR_FIRST + 40;
const UINT uiLastUserToolBarId = uiFirstUserToolBarId + iMaxUserToolbars - 1;

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWndEx)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_VIEW_CUSTOMIZE, &CMainFrame::OnViewCustomize)
	ON_REGISTERED_MESSAGE(AFX_WM_CREATETOOLBAR, &CMainFrame::OnToolbarCreateNew)
	ON_COMMAND_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnApplicationLook)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnUpdateApplicationLook)
	ON_COMMAND(IDD_EX1, &CMainFrame::OnEx1)
	ON_COMMAND(IDD_EX2, &CMainFrame::OnEx2)
	ON_COMMAND(IDD_EX3, &CMainFrame::OnEx3)
	ON_COMMAND(IDD_EX4, &CMainFrame::OnEx4)
	ON_COMMAND(IDD_EX5, &CMainFrame::OnEx5)
	ON_COMMAND(IDD_EX6, &CMainFrame::OnEx6)
	ON_COMMAND(IDD_EX7, &CMainFrame::OnEx7)
	ON_COMMAND(IDD_EX8, &CMainFrame::OnEx8)
	ON_COMMAND(IDD_EX9, &CMainFrame::OnEx9)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // ���A�C���ܾ�
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

// CMainFrame �غc/�Ѻc

CMainFrame::CMainFrame()
{
	// TODO: �b���[�J������l�Ƶ{���X
	theApp.m_nAppLook = theApp.GetInt(_T("ApplicationLook"), ID_VIEW_APPLOOK_VS_2008);
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	BOOL bNameValid;

	if (!m_wndMenuBar.Create(this))
	{
		TRACE0("�L�k�إߥ\����C\n");
		return -1;      // �L�k�إ�
	}

	m_wndMenuBar.SetPaneStyle(m_wndMenuBar.GetPaneStyle() | CBRS_SIZE_DYNAMIC | CBRS_TOOLTIPS | CBRS_FLYBY);

	// ����\����C�b�ҥήɨ��o�J�I
	CMFCPopupMenu::SetForceMenuFocus(FALSE);

	// �إߦ���ج[�u�@�Ϫ��˵�
	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW, CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	{
		TRACE0("�L�k�إ��˵�����\n");
		return -1;
	}

	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(theApp.m_bHiColorIcons ? IDR_MAINFRAME_256 : IDR_MAINFRAME))
	{
		TRACE0("�L�k�إߤu��C\n");
		return -1;      // �L�k�إ�
	}

	CString strToolBarName;
	bNameValid = strToolBarName.LoadString(IDS_TOOLBAR_STANDARD);
	ASSERT(bNameValid);
	m_wndToolBar.SetWindowText(strToolBarName);

	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);
	m_wndToolBar.EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);

	// ���\�ϥΪ̩w�q���u��C�@�~: 
	InitUserToolbars(NULL, uiFirstUserToolBarId, uiLastUserToolBarId);

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("�L�k�إߪ��A�C\n");
		return -1;      // �L�k�إ�
	}
	m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT));

	// TODO: �p�G���Ʊ�u��C�M�\����C���i���n�A�ЧR���o 5 ��
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndMenuBar);
	DockPane(&m_wndToolBar);


	// �ҥ� Visual Studio 2005 �˦����n�����欰
	CDockingManager::SetDockingMode(DT_SMART);
	// �ҥ� Visual Studio 2005 �˦����n�����۰����æ欰
	EnableAutoHidePanes(CBRS_ALIGN_ANY);
	// �ھګ���ȳ]�w��ı�ƺ޲z���M�˦�
	OnApplicationLook(theApp.m_nAppLook);

	// �ҥΤu��C�M���n�����\������N
	EnablePaneMenu(TRUE, ID_VIEW_CUSTOMIZE, strCustomize, ID_VIEW_TOOLBAR);

	// �ҥΧֳt (Alt+�즲) �u��C�ۭq
	CMFCToolBar::EnableQuickCustomization();

	if (CMFCToolBar::GetUserImages() == NULL)
	{
		// ���J�ϥΪ̩w�q���u��C�v��
		if (m_UserImages.Load(_T(".\\UserImages.bmp")))
		{
			CMFCToolBar::SetUserImages(&m_UserImages);
		}
	}

	// �ҥΥ\����ӤH�� (�̪�ϥΪ��R�O)
	// TODO: �w�q�z�ۤv���򥻩R�O�A�T�w�C�ӤU�Ԧ��\������ܤ֦��@�Ӱ򥻩R�O�C
	CList<UINT, UINT> lstBasicCommands;

	lstBasicCommands.AddTail(ID_APP_EXIT);
	lstBasicCommands.AddTail(ID_EDIT_CUT);
	lstBasicCommands.AddTail(ID_EDIT_PASTE);
	lstBasicCommands.AddTail(ID_EDIT_UNDO);
	lstBasicCommands.AddTail(ID_APP_ABOUT);
	lstBasicCommands.AddTail(ID_VIEW_STATUS_BAR);
	lstBasicCommands.AddTail(ID_VIEW_TOOLBAR);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2003);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_VS_2005);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_BLUE);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_SILVER);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_BLACK);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_AQUA);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_WINDOWS_7);

	CMFCToolBar::SetBasicCommands(lstBasicCommands);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWndEx::PreCreateWindow(cs) )
		return FALSE;
	// TODO: �b���g�ѭק� CREATESTRUCT cs 
	// �F��ק�������O�μ˦����ت�

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);
	return TRUE;
}

// CMainFrame �E�_

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWndEx::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWndEx::Dump(dc);
}
#endif //_DEBUG


// CMainFrame �T���B�z�`��

void CMainFrame::OnSetFocus(CWnd* /*pOldWnd*/)
{
	// ��e�J�I���˵�����
	m_wndView.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// ���˵��b�R�O���Ĥ@�ӵѨ�
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// �_�h�A����w�]���B�z
	return CFrameWndEx::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void CMainFrame::OnViewCustomize()
{
	CMFCToolBarsCustomizeDialog* pDlgCust = new CMFCToolBarsCustomizeDialog(this, TRUE /* ���y�\��� */);
	pDlgCust->EnableUserDefinedToolbars();
	pDlgCust->Create();
}

LRESULT CMainFrame::OnToolbarCreateNew(WPARAM wp,LPARAM lp)
{
	LRESULT lres = CFrameWndEx::OnToolbarCreateNew(wp,lp);
	if (lres == 0)
	{
		return 0;
	}

	CMFCToolBar* pUserToolbar = (CMFCToolBar*)lres;
	ASSERT_VALID(pUserToolbar);

	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
	return lres;
}

void CMainFrame::OnApplicationLook(UINT id)
{
	CWaitCursor wait;

	theApp.m_nAppLook = id;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_WIN_2000:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManager));
		break;

	case ID_VIEW_APPLOOK_OFF_XP:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOfficeXP));
		break;

	case ID_VIEW_APPLOOK_WIN_XP:
		CMFCVisualManagerWindows::m_b3DTabsXPTheme = TRUE;
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));
		break;

	case ID_VIEW_APPLOOK_OFF_2003:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2003));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_VS_2005:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2005));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_VS_2008:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2008));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_WINDOWS_7:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows7));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	default:
		switch (theApp.m_nAppLook)
		{
		case ID_VIEW_APPLOOK_OFF_2007_BLUE:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_LunaBlue);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_BLACK:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_ObsidianBlack);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_SILVER:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Silver);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_AQUA:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Aqua);
			break;
		}

		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2007));
		CDockingManager::SetDockingMode(DT_SMART);
	}

	RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE | RDW_UPDATENOW | RDW_FRAME | RDW_ERASE);

	theApp.WriteInt(_T("ApplicationLook"), theApp.m_nAppLook);
}

void CMainFrame::OnUpdateApplicationLook(CCmdUI* pCmdUI)
{
	pCmdUI->SetRadio(theApp.m_nAppLook == pCmdUI->m_nID);
}


BOOL CMainFrame::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd* pParentWnd, CCreateContext* pContext) 
{
	// �����O�q�ƹ�ڧ@�~

	if (!CFrameWndEx::LoadFrame(nIDResource, dwDefaultStyle, pParentWnd, pContext))
	{
		return FALSE;
	}


	// �ҥΩҦ��ϥΪ̤u��C���ۭq���s
	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	for (int i = 0; i < iMaxUserToolbars; i ++)
	{
		CMFCToolBar* pUserToolbar = GetUserToolBarByIndex(i);
		if (pUserToolbar != NULL)
		{
			pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
		}
	}

	return TRUE;
}



void CMainFrame::OnEx1()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	srand(time(NULL));
	int a, b;
	CString o2;
	a = rand();
	b = rand();

	if (a > b) 
	{
		o2.Format(_T("%d is larger than %d"), a, b);
	}
	else if(a == b) 
	{
		o2.Format(_T("%d = %d"), a, b);
	}
	else 
	{
		o2.Format(_T("%d is larger than %d"), b, a);
	}

	AfxMessageBox(o2);
}


void CMainFrame::OnEx2()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	srand(time(NULL));
	int a, b, c;
	CString o2;
	a = rand();
	b = rand();
	c = rand();
	if (a > b&&a > c) 
	{
		if (b > c) 
		{
			o2.Format(_T("%d > %d > %d"), a, b, c);
		}
		else 
		{
			o2.Format(_T("%d > %d > %d"), a, c, b);
		}
	}
	else if (b > a&&b > c) 
	{
		if (a > c)
		{
			o2.Format(_T("%d > %d > %d"), b, a, c);
		}
		else
		{
			o2.Format(_T("%d > %d > %d"), b, c, a);
		}
	}
	else if (c > a&&c > b) 
	{
		if (a > b)
		{
			o2.Format(_T("%d > %d > %d"), c, a, b);
		}
		else
		{
			o2.Format(_T("%d > %d > %d"), c, b, a);
		}
	}

	AfxMessageBox(o2);
}


void CMainFrame::OnEx3()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\input8.txt", "r");
	int i, j;
	int A[3][3], B[3][3], C[3][3], D[3][3];

	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 9; j++)
		{
			int a = j / 3;
			int b = j % 3;
			int tmp;
			fscanf_s(fp, "%d", &tmp);
			switch (i)
			{
			case 0:
				A[a][b] = tmp;
				break;
			case 1:
				B[a][b] = tmp;
				break;
			case 2:
				C[a][b] = tmp;
				break;
			}
		}
	}
	fclose(fp);

	FILE *fp2;
	fopen_s(&fp2, "..\\test3.txt", "w");

	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			D[i][j] = A[i][j] + B[i][j] - C[i][j];
			fprintf(fp2, "%d\t", D[i][j]);
		}
		fprintf(fp2, "\n");
	}
	fclose(fp2);

	CString file = _T("..\\test3.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}



void CMainFrame::OnEx4()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	srand(time(NULL));
	int A[100], i;
	FILE *fp;
	fopen_s(&fp, "..\\test4.txt", "w");

	for (i = 0; i < 100; i++)
	{
		A[i] = rand();
		fprintf(fp, "%d\n", A[i]);
	}

	fclose(fp);

	CString file = _T("..\\test4.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);


	CString o2;
	o2.Format(_T("34th = %d\n97th = %d"), A[33], A[96]);
	AfxMessageBox(o2);


}


void CMainFrame::OnEx5()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	srand(time(NULL));

	int *A;
	A = new int[10000];

	for (int i = 0; i < 10000; i++) 
	{
		A[i] = rand();
	}

	CString str;
	str.Format(_T("Last num: %d"), A[9999]);
	AfxMessageBox(str);

	delete[]A;
}

void CMainFrame::OnEx6()
{
	srand(time(NULL));
	// �ŧi�ʺA�}�C A B C D E
	int *A, *B, *C, *D, *E;
	A = new int[1000];
	B = new int[5000];
	C = new int[10000];
	D = new int[50000];
	E = new int[100000];
	
	//�ŧi��l�ܼ�
	int c, Num = 1, i;

	//�ᤩ�}�C A B C D E �üƭ�
	for(c=0;c<5;c++)
	{
		switch(c)
		{
		case 0:
			Num = 1000;
			for(i=0;i<Num;i++)
				A[i] = rand();
			break;
		case 1:
			Num = 5000;
			for(i=0;i<Num;i++)
				B[i] = rand();
			break;
		case 2:
			Num = 10000;
			for (i = 0; i<Num; i++)
				C[i] = rand();
			break;
		case 3:
			Num = 50000;
			for (i = 0; i<Num; i++)
				D[i] = rand();
			break;
		case 4:
			Num = 100000;
			for (i = 0; i<Num; i++)
				E[i] = rand();
			break;
		}
	}

	//�ܼƪ�l��
	c = 0;
	Num = 1;
	int j, k;

	FILE *fp;
	fopen_s(&fp, "..\\test6.txt", "w");
	fprintf(fp, "NO.\tMax.\tMin.\tAvg.\n");

	for (i = 0; i < 5; i++) 
	{
		int Sum = 0, tmp = 0;
		double avg = 0;
		switch (i)
		{
		case 0:
			Num = 1000;
			//�Ƨǰ}�C
			for (j = 0; j < Num; j++) 
			{
				for (k = j; k < Num; k++) 
				{
					if (A[j] < A[k])
					{
						tmp = A[j];
						A[j] = A[k];
						A[k] = tmp;
					}
				}
			}
			//�`�M
			for (j = 0; j < Num; j++) 
			{
				Sum = Sum + A[j];
			}
			//����
			avg = (double)Sum / (double)Num;
			//��X
			fprintf(fp, "%d\t%d\t%d\t%.5f\n", Num, A[0], A[Num - 1], avg);
			break;
		case 1:
			Num = 5000;

			for (j = 0; j < Num; j++)
			{
				for (k = j; k < Num; k++)
				{
					if (B[j] < B[k])
					{
						tmp = B[j];
						B[j] = B[k];
						B[k] = tmp;
					}
				}
			}

			for (j = 0; j < Num; j++)
			{
				Sum = Sum + B[j];
			}
			avg = (double)Sum / (double)Num;
			fprintf(fp, "%d\t%d\t%d\t%.5f\n", Num, B[0], B[Num - 1], avg);
			break;
		case 2:
			Num = 10000;

			for (j = 0; j < Num; j++)
			{
				for (k = j; k < Num; k++)
				{
					if (C[j] < C[k])
					{
						tmp = C[j];
						C[j] = C[k];
						C[k] = tmp;
					}
				}
			}

			for (j = 0; j < Num; j++)
			{
				Sum = Sum + C[j];
			}
			avg = (double)Sum / (double)Num;
			fprintf(fp, "%d\t%d\t%d\t%.5f\n", Num, C[0], C[Num - 1], avg);
			break;
		case 3:
			Num = 50000;

			for (j = 0; j < Num; j++)
			{
				for (k = j; k < Num; k++)
				{
					if (D[j] < D[k])
					{
						tmp = D[j];
						D[j] = D[k];
						D[k] = tmp;
					}
				}
			}

			for (j = 0; j < Num; j++)
			{
				Sum = Sum + D[j];
			}
			avg = (double)Sum / (double)Num;
			fprintf(fp, "%d\t%d\t%d\t%.5f\n", Num, D[0], D[Num - 1], avg);
			break;
		case 4:
			Num = 100000;
			
			for (j = 0; j < Num; j++)
			{
				for (k = j; k < Num; k++)
				{
					if (E[j] < E[k])
					{
						tmp = E[j];
						E[j] = E[k];
						E[k] = tmp;
					}
				}
			}

			for (j = 0; j < Num; j++)
			{
				Sum = Sum + E[j];
			}
			avg = (double)Sum / (double)Num;
			fprintf(fp, "%d\t%d\t%d\t%.5f\n", Num, E[0], E[99999], avg);
			break;
		}
	}
	fclose(fp);

	CString file = _T("..\\test6.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);

	delete[]A;
	delete[]B;
	delete[]C;
	delete[]D;
	delete[]E;
}


void CMainFrame::OnEx7()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	srand(time(NULL));
	int A[100], Count[6]{0}, i;
	double P[6];

	for (i = 0; i < 100; i++)//�ͦ��üơB�p��1~6�X�{�X�� 
	{
		A[i] = rand() % 6 + 1;
		switch (A[i]) 
		{
		case 1:
			Count[0]++;
			break;
		case 2:
			Count[1]++;
			break;
		case 3:
			Count[2]++;
			break;
		case 4:
			Count[3]++;
			break;
		case 5:
			Count[4]++;
			break;
		case 6:
			Count[5]++;
			break;
		}
	}

	for (i = 0; i < 6; i++)//�p��ӧO���v 
	{
		P[i] = (double) Count[i] / 100;
	}
	
	CString o2;
	o2.Format(_T("NO.1\tP = %.3f\nNO.2\tP = %.3f\nNO.3\tP = %.3f\nNO.4\tP = %.3f\nNO.5\tP = %.3f\nNO.6\tP = %.3f\n"), P[0], P[1], P[2], P[3], P[4], P[5]);
	AfxMessageBox(o2);
}


void CMainFrame::OnEx8()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	srand(time(NULL));
	int MinNum = 1000;
	int MaxNum = 100000;
	int delta = 1000;
	int times = MaxNum / delta;

	int **Result;
	Result = new int*[times];
	for (int i = 0; i < times; i++) 
	{
		Result[i] = new int[7]{0};
	}

	for (int i = 0; i < times; i++) 
	{
		int SNum = MinNum + delta*i;
		Result[i][0] = SNum;

		for (int j = 0; j < SNum; j++) 
		{
			int RollNum = rand() % 6 + 1;

			//�p��
			if      (RollNum == 1) Result[i][1]++;
			else if (RollNum == 2) Result[i][2]++;
			else if (RollNum == 3) Result[i][3]++;
			else if (RollNum == 4) Result[i][4]++;
			else if (RollNum == 5) Result[i][5]++;
			else if (RollNum == 6) Result[i][6]++;
		}
	}

	FILE *fp;
	fopen_s(&fp, "..\\test8.txt", "w");
	fprintf(fp, "NO.\t1(P)\t2(P)\t3(P)\t4(P)\t5(P)\t6(P)\n");//�Ĥ@�C���D
	for (int i = 0; i < times; i++) 
	{
		for (int j = 0; j < 7; j++) 
		{
			if (j == 0) 
			{
				fprintf(fp, "%d\t", Result[i][j]);
			}
			else 
			{
				double P = (double) Result[i][j] / Result[i][0];
				fprintf(fp, "%1.3f\t", P);
			}
		}
		fprintf(fp, "\n");
	}
	fclose(fp);

	CString file = _T("..\\test8.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);


	for (int i = times - 1; i >= 0; i--)//����}�C�O����Ŷ� 
	{
		delete[]Result[i];//�M�z���
	}
	delete[]Result;//�M�z�C��
}


void CMainFrame::OnEx9()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	srand(time(NULL));
	int a[10], i, j;
	for (i = 0; i < 10; i++) 
	{
		a[i] = rand();
	}
	for (i = 0; i < 10; i++) 
	{
		for (j = i; j < 10; j++) 
		{
			if (a[i] < a[j]) 
			{
				int tmp;
				tmp = a[i];
				a[i] = a[j];
				a[j] = tmp;
			}
		}
	}
	CString o2;
	o2.Format(_T("%d %d %d %d %d %d %d %d %d"), a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
	AfxMessageBox(o2);
}
