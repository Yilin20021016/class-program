
// MainFrm.cpp : CMainFrame ���O����@
//

#include "stdafx.h"
#include "110303512_HW11.h"

#include "MainFrm.h"
#include "math.h"
#include "DTest6.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWndEx)

const int  iMaxUserToolbars = 10;
const UINT uiFirstUserToolBarId = AFX_IDW_CONTROLBAR_FIRST + 40;
const UINT uiLastUserToolBarId = uiFirstUserToolBarId + iMaxUserToolbars - 1;

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWndEx)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_VIEW_CUSTOMIZE, &CMainFrame::OnViewCustomize)
	ON_REGISTERED_MESSAGE(AFX_WM_CREATETOOLBAR, &CMainFrame::OnToolbarCreateNew)
	ON_COMMAND_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnApplicationLook)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnUpdateApplicationLook)
	ON_COMMAND(IDD_EX1, &CMainFrame::OnEx1)
	ON_COMMAND(IDD_EX2, &CMainFrame::OnEx2)
	ON_COMMAND(IDD_EX3, &CMainFrame::OnEx3)
	ON_COMMAND(IDD_EX4, &CMainFrame::OnEx4)
	ON_COMMAND(IDD_EX5, &CMainFrame::OnEx5)
	ON_COMMAND(IDD_EX6, &CMainFrame::OnEx6)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // ���A�C���ܾ�
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

// CMainFrame �غc/�Ѻc

CMainFrame::CMainFrame()
{
	// TODO: �b���[�J������l�Ƶ{���X
	theApp.m_nAppLook = theApp.GetInt(_T("ApplicationLook"), ID_VIEW_APPLOOK_VS_2008);
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	BOOL bNameValid;

	if (!m_wndMenuBar.Create(this))
	{
		TRACE0("�L�k�إߥ\����C\n");
		return -1;      // �L�k�إ�
	}

	m_wndMenuBar.SetPaneStyle(m_wndMenuBar.GetPaneStyle() | CBRS_SIZE_DYNAMIC | CBRS_TOOLTIPS | CBRS_FLYBY);

	// ����\����C�b�ҥήɨ��o�J�I
	CMFCPopupMenu::SetForceMenuFocus(FALSE);

	// �إߦ���ج[�u�@�Ϫ��˵�
	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW, CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	{
		TRACE0("�L�k�إ��˵�����\n");
		return -1;
	}

	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(theApp.m_bHiColorIcons ? IDR_MAINFRAME_256 : IDR_MAINFRAME))
	{
		TRACE0("�L�k�إߤu��C\n");
		return -1;      // �L�k�إ�
	}

	CString strToolBarName;
	bNameValid = strToolBarName.LoadString(IDS_TOOLBAR_STANDARD);
	ASSERT(bNameValid);
	m_wndToolBar.SetWindowText(strToolBarName);

	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);
	m_wndToolBar.EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);

	// ���\�ϥΪ̩w�q���u��C�@�~: 
	InitUserToolbars(NULL, uiFirstUserToolBarId, uiLastUserToolBarId);

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("�L�k�إߪ��A�C\n");
		return -1;      // �L�k�إ�
	}
	m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT));

	// TODO: �p�G���Ʊ�u��C�M�\����C���i���n�A�ЧR���o 5 ��
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndMenuBar);
	DockPane(&m_wndToolBar);


	// �ҥ� Visual Studio 2005 �˦����n�����欰
	CDockingManager::SetDockingMode(DT_SMART);
	// �ҥ� Visual Studio 2005 �˦����n�����۰����æ欰
	EnableAutoHidePanes(CBRS_ALIGN_ANY);
	// �ھګ���ȳ]�w��ı�ƺ޲z���M�˦�
	OnApplicationLook(theApp.m_nAppLook);

	// �ҥΤu��C�M���n�����\������N
	EnablePaneMenu(TRUE, ID_VIEW_CUSTOMIZE, strCustomize, ID_VIEW_TOOLBAR);

	// �ҥΧֳt (Alt+�즲) �u��C�ۭq
	CMFCToolBar::EnableQuickCustomization();

	if (CMFCToolBar::GetUserImages() == NULL)
	{
		// ���J�ϥΪ̩w�q���u��C�v��
		if (m_UserImages.Load(_T(".\\UserImages.bmp")))
		{
			CMFCToolBar::SetUserImages(&m_UserImages);
		}
	}

	// �ҥΥ\����ӤH�� (�̪�ϥΪ��R�O)
	// TODO: �w�q�z�ۤv���򥻩R�O�A�T�w�C�ӤU�Ԧ��\������ܤ֦��@�Ӱ򥻩R�O�C
	CList<UINT, UINT> lstBasicCommands;

	lstBasicCommands.AddTail(ID_APP_EXIT);
	lstBasicCommands.AddTail(ID_EDIT_CUT);
	lstBasicCommands.AddTail(ID_EDIT_PASTE);
	lstBasicCommands.AddTail(ID_EDIT_UNDO);
	lstBasicCommands.AddTail(ID_APP_ABOUT);
	lstBasicCommands.AddTail(ID_VIEW_STATUS_BAR);
	lstBasicCommands.AddTail(ID_VIEW_TOOLBAR);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2003);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_VS_2005);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_BLUE);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_SILVER);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_BLACK);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_AQUA);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_WINDOWS_7);

	CMFCToolBar::SetBasicCommands(lstBasicCommands);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWndEx::PreCreateWindow(cs) )
		return FALSE;
	// TODO: �b���g�ѭק� CREATESTRUCT cs 
	// �F��ק�������O�μ˦����ت�

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);
	return TRUE;
}

// CMainFrame �E�_

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWndEx::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWndEx::Dump(dc);
}
#endif //_DEBUG


// CMainFrame �T���B�z�`��

void CMainFrame::OnSetFocus(CWnd* /*pOldWnd*/)
{
	// ��e�J�I���˵�����
	m_wndView.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// ���˵��b�R�O���Ĥ@�ӵѨ�
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// �_�h�A����w�]���B�z
	return CFrameWndEx::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void CMainFrame::OnViewCustomize()
{
	CMFCToolBarsCustomizeDialog* pDlgCust = new CMFCToolBarsCustomizeDialog(this, TRUE /* ���y�\��� */);
	pDlgCust->EnableUserDefinedToolbars();
	pDlgCust->Create();
}

LRESULT CMainFrame::OnToolbarCreateNew(WPARAM wp,LPARAM lp)
{
	LRESULT lres = CFrameWndEx::OnToolbarCreateNew(wp,lp);
	if (lres == 0)
	{
		return 0;
	}

	CMFCToolBar* pUserToolbar = (CMFCToolBar*)lres;
	ASSERT_VALID(pUserToolbar);

	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
	return lres;
}

void CMainFrame::OnApplicationLook(UINT id)
{
	CWaitCursor wait;

	theApp.m_nAppLook = id;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_WIN_2000:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManager));
		break;

	case ID_VIEW_APPLOOK_OFF_XP:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOfficeXP));
		break;

	case ID_VIEW_APPLOOK_WIN_XP:
		CMFCVisualManagerWindows::m_b3DTabsXPTheme = TRUE;
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));
		break;

	case ID_VIEW_APPLOOK_OFF_2003:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2003));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_VS_2005:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2005));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_VS_2008:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2008));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_WINDOWS_7:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows7));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	default:
		switch (theApp.m_nAppLook)
		{
		case ID_VIEW_APPLOOK_OFF_2007_BLUE:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_LunaBlue);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_BLACK:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_ObsidianBlack);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_SILVER:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Silver);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_AQUA:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Aqua);
			break;
		}

		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2007));
		CDockingManager::SetDockingMode(DT_SMART);
	}

	RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE | RDW_UPDATENOW | RDW_FRAME | RDW_ERASE);

	theApp.WriteInt(_T("ApplicationLook"), theApp.m_nAppLook);
}

void CMainFrame::OnUpdateApplicationLook(CCmdUI* pCmdUI)
{
	pCmdUI->SetRadio(theApp.m_nAppLook == pCmdUI->m_nID);
}


BOOL CMainFrame::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd* pParentWnd, CCreateContext* pContext) 
{
	// �����O�q�ƹ�ڧ@�~

	if (!CFrameWndEx::LoadFrame(nIDResource, dwDefaultStyle, pParentWnd, pContext))
	{
		return FALSE;
	}


	// �ҥΩҦ��ϥΪ̤u��C���ۭq���s
	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	for (int i = 0; i < iMaxUserToolbars; i ++)
	{
		CMFCToolBar* pUserToolbar = GetUserToolBarByIndex(i);
		if (pUserToolbar != NULL)
		{
			pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
		}
	}

	return TRUE;
}



void CMainFrame::OnEx1()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	XYZPoint P1, P2;

	P1.X = 0;
	P1.Y = 0;
	P1.Z = 0;

	P2.X = 1;
	P2.Y = 1;
	P2.Z = 1;

	XYZPoint Vu;
	double length;

	length = sqrt(pow(P2.X - P1.X, 2) + pow(P2.Y - P1.Y, 2) + pow(P2.Z - P1.Z, 2));

	Vu.X = (P2.X - P1.X) / length;
	Vu.Y = (P2.Y - P1.Y) / length;
	Vu.Z = (P2.Z - P1.Z) / length;

	CString str, output = _T("");
	str.Format(_T("P1 (%.2f, %.2f, %.2f)\n"), P1.X, P1.Y, P1.Z);
	output += str;
	str.Format(_T("P2 (%.2f, %.2f, %.2f)\n"), P2.X, P2.Y, P2.Z);
	output += str;
	str.Format(_T("Vu (%.2f, %.2f, %.2f)\n"), Vu.X, Vu.Y, Vu.Z);
	output += str;

	AfxMessageBox(output);
}

XYZPoint::XYZPoint() 
{
	X = 0;
	Y = 0;
	Z = 0;
}


void CMainFrame::OnEx2()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	Edge e1, e2, e3;

	e1.P1.X = 0;
	e1.P1.Y = 0;
	e1.P1.Z = 0;
	e1.P2.X = 1;
	e1.P2.Y = 0;
	e1.P2.Z = 0;

	e2.P1.X = 1;
	e2.P1.Y = 0;
	e2.P1.Z = 0;
	e2.P2.X = 0.5;
	e2.P2.Y = 0.5;
	e2.P2.Z = 0.5;

	e3.P1.X = 0.5;
	e3.P1.Y = 0.5;
	e3.P1.Z = 0.5;
	e3.P2.X = 0;
	e3.P2.Y = 0;
	e3.P2.Z = 0;

	XYZPoint P1_Mid;

	P1_Mid.X = (e1.P1.X + e1.P2.X) / 2;
	P1_Mid.Y = (e1.P1.Y + e1.P2.Y) / 2;
	P1_Mid.Z = (e1.P1.Z + e1.P2.Z) / 2;

	CString coordinate;
	coordinate.Format(_T("P1_Mid = (%.2f, %.2f, %.2f)"), P1_Mid.X, P1_Mid.Y, P1_Mid.Z);

	AfxMessageBox(coordinate);
}

Edge::Edge()
{
	P1.X = 0;
	P1.Y = 0;
	P1.Z = 0;
	P2.X = 0;
	P2.Y = 0;
	P2.Z = 0;
}

XYZPoint Q1, Q2, Q3;
void CMainFrame::OnEx3()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	
	FILE *fp;
	fopen_s(&fp, "..\\input1.txt", "r");
	fscanf_s(fp, "%lf\t%lf\t%lf\n", &Q1.X, &Q1.Y, &Q1.Z);
	fscanf_s(fp, "%lf\t%lf\t%lf\n", &Q2.X, &Q2.Y, &Q2.Z);
	fscanf_s(fp, "%lf\t%lf\t%lf\n", &Q3.X, &Q3.Y, &Q3.Z);
	fclose(fp);

	CString o2;
	o2.Format(_T("Q1 = (%g, %g, %g)\nQ2 = (%g, %g, %g)\nQ3 = (%g, %g, %g)\n"), Q1.X, Q1.Y, Q1.Z, Q2.X, Q2.Y, Q2.Z, Q3.X, Q3.Y, Q3.Z);
	AfxMessageBox(o2);

	//��l��input1.txt
	fopen_s(&fp, "..\\input1.txt", "w");
	fprintf(fp, "%.2f  %.2f  %.2f\n", Q1.X, Q1.Y, Q1.Z);
	fprintf(fp, "%.2f  %.2f  %.2f\n", Q2.X, Q2.Y, Q2.Z);
	fprintf(fp, "%.2f  %.2f  %.2f\n", Q3.X, Q3.Y, Q3.Z);
	fclose(fp);
}


void CMainFrame::OnEx4()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\input1.txt", "a");
	XYZPoint avgpoint;
	avgpoint.X = (Q1.X + Q2.X + Q3.X) / 3;
	avgpoint.Y = (Q1.Y + Q2.Y + Q3.Y) / 3;
	avgpoint.Z = (Q1.Z + Q2.Z + Q3.Z) / 3;
	fprintf(fp, "\n");
	fprintf(fp, "Average Point: %.2f  %.2f  %.2f\n", avgpoint.X, avgpoint.Y, avgpoint.Z);
	fprintf(fp, "You could get the data and initialize this file by pressing Ex3");
	fclose(fp);

	CString file = _T("..\\input1.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx5()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	XYZPoint v12, v13;

	v12.X = Q2.X - Q1.X;
	v12.Y = Q2.Y - Q1.Y;
	v12.Z = Q2.Z - Q1.Z;
	v13.X = Q3.X - Q1.X;
	v13.Y = Q3.Y - Q1.Y;
	v13.Z = Q3.Z - Q1.Z;

	double delta_v = (v12.X*v13.X + v12.Y*v13.Y + v12.Z*v13.Z) / (pow(v13.X, 2) + pow(v13.Y, 2) + pow(v13.Z, 2));

	XYZPoint projecting_point;
	
	projecting_point.X = delta_v*v13.X + Q1.X;
	projecting_point.Y = delta_v*v13.Y + Q1.Y;
	projecting_point.Z = delta_v*v13.Z + Q1.Z;
	
	double distance = sqrt(pow(Q3.X - projecting_point.X, 2) + pow(Q3.Y - projecting_point.Y, 2) + pow(Q3.Z - projecting_point.Z, 2));

	CString o2;
	o2.Format(_T("Projecting point = ( %.2f, %.2f, %.2f )\nDistance = %.2f"), projecting_point.X, projecting_point.Y, projecting_point.Z, distance);
	AfxMessageBox(o2);
}


void CMainFrame::OnEx6()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	CDTest6 dlg;
	dlg.DoModal();
}


