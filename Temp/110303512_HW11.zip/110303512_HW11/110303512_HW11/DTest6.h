#pragma once


// CDTest6 ��ܤ��

//Ex6
class Matrix
{
public:
	Matrix()
	{
		e_11 = 0;
		e_12 = 0;
		e_21 = 0;
		e_22 = 0;
	};

	int e_11;
	int e_12;
	int e_21;
	int e_22;
};

class CDTest6 : public CDialogEx
{
	DECLARE_DYNAMIC(CDTest6)

public:
	CDTest6(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDTest6();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	Matrix A;
	Matrix B;
	Matrix Result;
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
};
