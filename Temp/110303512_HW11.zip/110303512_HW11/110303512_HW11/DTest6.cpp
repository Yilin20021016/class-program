// DTest6.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW11.h"
#include "DTest6.h"
#include "afxdialogex.h"


// CDTest6 ��ܤ��

IMPLEMENT_DYNAMIC(CDTest6, CDialogEx)

CDTest6::CDTest6(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG1, pParent)

{

}

CDTest6::~CDTest6()
{
}

void CDTest6::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT9, A.e_11);
	DDX_Text(pDX, IDC_EDIT10, A.e_21);
	DDX_Text(pDX, IDC_EDIT11, A.e_12);
	DDX_Text(pDX, IDC_EDIT12, A.e_22);
	DDX_Text(pDX, IDC_EDIT13, B.e_11);
	DDX_Text(pDX, IDC_EDIT14, B.e_21);
	DDX_Text(pDX, IDC_EDIT15, B.e_12);
	DDX_Text(pDX, IDC_EDIT16, B.e_22);
	DDX_Text(pDX, IDC_EDIT17, Result.e_11);
	DDX_Text(pDX, IDC_EDIT18, Result.e_21);
	DDX_Text(pDX, IDC_EDIT19, Result.e_12);
	DDX_Text(pDX, IDC_EDIT20, Result.e_22);
}


BEGIN_MESSAGE_MAP(CDTest6, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDTest6::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CDTest6::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CDTest6::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &CDTest6::OnBnClickedButton4)
END_MESSAGE_MAP()


// CDTest6 �T���B�z�`��


void CDTest6::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);

	Result.e_11 = A.e_11 + B.e_11;
	Result.e_21 = A.e_21 + B.e_21;
	Result.e_12 = A.e_12 + B.e_12;
	Result.e_22 = A.e_22 + B.e_22;

	UpdateData(FALSE);
}


void CDTest6::OnBnClickedButton2()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	
	Result.e_11 = A.e_11 - B.e_11;
	Result.e_21 = A.e_21 - B.e_21;
	Result.e_12 = A.e_12 - B.e_12;
	Result.e_22 = A.e_22 - B.e_22;

	UpdateData(FALSE);
}


void CDTest6::OnBnClickedButton3()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);

	Result.e_11 = A.e_11*B.e_11 + A.e_21*B.e_12;
	Result.e_21 = A.e_11*B.e_21 + A.e_21*B.e_22;
	Result.e_12 = A.e_12*B.e_11 + A.e_22*B.e_12;
	Result.e_22 = A.e_12*B.e_21 + A.e_22*B.e_22;

	UpdateData(FALSE);
}


void CDTest6::OnBnClickedButton4()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);

	int value_A = A.e_11*A.e_22 - A.e_12*A.e_21;
	int value_B = B.e_11*B.e_22 - B.e_12*B.e_21;

	CString o2;
	o2.Format(_T("��C���� of A = %d\n��C���� of B = %d"), value_A, value_B);

	AfxMessageBox(o2);

	UpdateData(FALSE);
}
