
// MainFrm.cpp : CMainFrame ���O����@
//

#include "stdafx.h"
#include "110303512_HW4.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWndEx)

const int  iMaxUserToolbars = 10;
const UINT uiFirstUserToolBarId = AFX_IDW_CONTROLBAR_FIRST + 40;
const UINT uiLastUserToolBarId = uiFirstUserToolBarId + iMaxUserToolbars - 1;

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWndEx)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_VIEW_CUSTOMIZE, &CMainFrame::OnViewCustomize)
	ON_REGISTERED_MESSAGE(AFX_WM_CREATETOOLBAR, &CMainFrame::OnToolbarCreateNew)
	ON_COMMAND_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnApplicationLook)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnUpdateApplicationLook)
	ON_COMMAND(IDD_EX1, &CMainFrame::OnEx1)
	ON_COMMAND(IDD_EX2, &CMainFrame::OnEx2)
	ON_COMMAND(IDD_EX3, &CMainFrame::OnEx3)
	ON_COMMAND(IDD_EX4, &CMainFrame::OnEx4)
	ON_COMMAND(IDD_EX5, &CMainFrame::OnEx5)
	ON_COMMAND(IDD_EX6, &CMainFrame::OnEx6)
	ON_COMMAND(IDD_EX7, &CMainFrame::OnEx7)
	ON_COMMAND(IDD_EX8, &CMainFrame::OnEx8)
	ON_COMMAND(IDD_EX9, &CMainFrame::OnEx9)
	ON_COMMAND(IDD_EX10, &CMainFrame::OnEx10)
	ON_COMMAND(IDD_EX11, &CMainFrame::OnEx11)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // ���A�C���ܾ�
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

// CMainFrame �غc/�Ѻc

CMainFrame::CMainFrame()
{
	// TODO: �b���[�J������l�Ƶ{���X
	theApp.m_nAppLook = theApp.GetInt(_T("ApplicationLook"), ID_VIEW_APPLOOK_VS_2008);
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	BOOL bNameValid;

	if (!m_wndMenuBar.Create(this))
	{
		TRACE0("�L�k�إߥ\����C\n");
		return -1;      // �L�k�إ�
	}

	m_wndMenuBar.SetPaneStyle(m_wndMenuBar.GetPaneStyle() | CBRS_SIZE_DYNAMIC | CBRS_TOOLTIPS | CBRS_FLYBY);

	// ����\����C�b�ҥήɨ��o�J�I
	CMFCPopupMenu::SetForceMenuFocus(FALSE);

	// �إߦ���ج[�u�@�Ϫ��˵�
	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW, CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	{
		TRACE0("�L�k�إ��˵�����\n");
		return -1;
	}

	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(theApp.m_bHiColorIcons ? IDR_MAINFRAME_256 : IDR_MAINFRAME))
	{
		TRACE0("�L�k�إߤu��C\n");
		return -1;      // �L�k�إ�
	}

	CString strToolBarName;
	bNameValid = strToolBarName.LoadString(IDS_TOOLBAR_STANDARD);
	ASSERT(bNameValid);
	m_wndToolBar.SetWindowText(strToolBarName);

	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);
	m_wndToolBar.EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);

	// ���\�ϥΪ̩w�q���u��C�@�~: 
	InitUserToolbars(NULL, uiFirstUserToolBarId, uiLastUserToolBarId);

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("�L�k�إߪ��A�C\n");
		return -1;      // �L�k�إ�
	}
	m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT));

	// TODO: �p�G���Ʊ�u��C�M�\����C���i���n�A�ЧR���o 5 ��
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndMenuBar);
	DockPane(&m_wndToolBar);


	// �ҥ� Visual Studio 2005 �˦����n�����欰
	CDockingManager::SetDockingMode(DT_SMART);
	// �ҥ� Visual Studio 2005 �˦����n�����۰����æ欰
	EnableAutoHidePanes(CBRS_ALIGN_ANY);
	// �ھګ���ȳ]�w��ı�ƺ޲z���M�˦�
	OnApplicationLook(theApp.m_nAppLook);

	// �ҥΤu��C�M���n�����\������N
	EnablePaneMenu(TRUE, ID_VIEW_CUSTOMIZE, strCustomize, ID_VIEW_TOOLBAR);

	// �ҥΧֳt (Alt+�즲) �u��C�ۭq
	CMFCToolBar::EnableQuickCustomization();

	if (CMFCToolBar::GetUserImages() == NULL)
	{
		// ���J�ϥΪ̩w�q���u��C�v��
		if (m_UserImages.Load(_T(".\\UserImages.bmp")))
		{
			CMFCToolBar::SetUserImages(&m_UserImages);
		}
	}

	// �ҥΥ\����ӤH�� (�̪�ϥΪ��R�O)
	// TODO: �w�q�z�ۤv���򥻩R�O�A�T�w�C�ӤU�Ԧ��\������ܤ֦��@�Ӱ򥻩R�O�C
	CList<UINT, UINT> lstBasicCommands;

	lstBasicCommands.AddTail(ID_APP_EXIT);
	lstBasicCommands.AddTail(ID_EDIT_CUT);
	lstBasicCommands.AddTail(ID_EDIT_PASTE);
	lstBasicCommands.AddTail(ID_EDIT_UNDO);
	lstBasicCommands.AddTail(ID_APP_ABOUT);
	lstBasicCommands.AddTail(ID_VIEW_STATUS_BAR);
	lstBasicCommands.AddTail(ID_VIEW_TOOLBAR);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2003);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_VS_2005);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_BLUE);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_SILVER);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_BLACK);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_AQUA);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_WINDOWS_7);

	CMFCToolBar::SetBasicCommands(lstBasicCommands);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWndEx::PreCreateWindow(cs) )
		return FALSE;
	// TODO: �b���g�ѭק� CREATESTRUCT cs 
	// �F��ק�������O�μ˦����ت�

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);
	return TRUE;
}

// CMainFrame �E�_

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWndEx::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWndEx::Dump(dc);
}
#endif //_DEBUG


// CMainFrame �T���B�z�`��

void CMainFrame::OnSetFocus(CWnd* /*pOldWnd*/)
{
	// ��e�J�I���˵�����
	m_wndView.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// ���˵��b�R�O���Ĥ@�ӵѨ�
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// �_�h�A����w�]���B�z
	return CFrameWndEx::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void CMainFrame::OnViewCustomize()
{
	CMFCToolBarsCustomizeDialog* pDlgCust = new CMFCToolBarsCustomizeDialog(this, TRUE /* ���y�\��� */);
	pDlgCust->EnableUserDefinedToolbars();
	pDlgCust->Create();
}

LRESULT CMainFrame::OnToolbarCreateNew(WPARAM wp,LPARAM lp)
{
	LRESULT lres = CFrameWndEx::OnToolbarCreateNew(wp,lp);
	if (lres == 0)
	{
		return 0;
	}

	CMFCToolBar* pUserToolbar = (CMFCToolBar*)lres;
	ASSERT_VALID(pUserToolbar);

	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
	return lres;
}

void CMainFrame::OnApplicationLook(UINT id)
{
	CWaitCursor wait;

	theApp.m_nAppLook = id;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_WIN_2000:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManager));
		break;

	case ID_VIEW_APPLOOK_OFF_XP:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOfficeXP));
		break;

	case ID_VIEW_APPLOOK_WIN_XP:
		CMFCVisualManagerWindows::m_b3DTabsXPTheme = TRUE;
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));
		break;

	case ID_VIEW_APPLOOK_OFF_2003:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2003));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_VS_2005:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2005));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_VS_2008:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2008));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_WINDOWS_7:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows7));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	default:
		switch (theApp.m_nAppLook)
		{
		case ID_VIEW_APPLOOK_OFF_2007_BLUE:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_LunaBlue);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_BLACK:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_ObsidianBlack);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_SILVER:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Silver);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_AQUA:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Aqua);
			break;
		}

		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2007));
		CDockingManager::SetDockingMode(DT_SMART);
	}

	RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE | RDW_UPDATENOW | RDW_FRAME | RDW_ERASE);

	theApp.WriteInt(_T("ApplicationLook"), theApp.m_nAppLook);
}

void CMainFrame::OnUpdateApplicationLook(CCmdUI* pCmdUI)
{
	pCmdUI->SetRadio(theApp.m_nAppLook == pCmdUI->m_nID);
}


BOOL CMainFrame::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd* pParentWnd, CCreateContext* pContext) 
{
	// �����O�q�ƹ�ڧ@�~

	if (!CFrameWndEx::LoadFrame(nIDResource, dwDefaultStyle, pParentWnd, pContext))
	{
		return FALSE;
	}


	// �ҥΩҦ��ϥΪ̤u��C���ۭq���s
	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	for (int i = 0; i < iMaxUserToolbars; i ++)
	{
		CMFCToolBar* pUserToolbar = GetUserToolBarByIndex(i);
		if (pUserToolbar != NULL)
		{
			pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
		}
	}

	return TRUE;
}



void CMainFrame::OnEx1()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\test1.txt", "w");

	for (int i = 1; i < 101; i++)
	{
		fprintf(fp, "%d\n", i);
	}
	fclose(fp);
	CString file = _T("..\\test1.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx2()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\test1.txt", "r");

	int Sum = 0, tmp;
	for (int i = 1; i < 101; i++) 
	{
		fscanf_s(fp, "%d", &tmp, sizeof(tmp));
		Sum += tmp;
	}
	CString output;
	output.Format(_T("Sum = %d"), Sum);
	AfxMessageBox(output);
}


void CMainFrame::OnEx3()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\test3.txt", "w");

	for (int i = 1; i < 101; i++) 
	{
		fprintf(fp, "%d\t", i);
		if (i % 5 == 0)
		{
			fprintf(fp, "\n");
		}
	}
	fclose(fp);

	CString file = _T("..\\test3.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx4()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp_read;
	FILE *fp_write;

	fopen_s(&fp_read, "..\\test3.txt", "r");
	fopen_s(&fp_write, "..\\test4.txt", "w");

	int tmpNum, Sum = 0;
	for (int i = 1; i < 101; i++) 
	{
		fscanf_s(fp_read, "%d", &tmpNum,sizeof(tmpNum));
		fprintf(fp_write, "%d\t", tmpNum);
		Sum += tmpNum;

		if (tmpNum % 5 == 0) 
		{
			fprintf(fp_write, "Sum = %d \n", Sum);
			Sum = 0;
		}
	}
	fclose(fp_read);
	fclose(fp_write);

	CString file = _T("..\\test4.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx5()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	srand(time(NULL));

	FILE *fp;
	fopen_s(&fp, "..\\test5.txt", "w");

	int Num;
	for (int i = 0; i < 1000; i++) 
	{
		Num = rand();
		fprintf(fp, "%d\n", Num);
	}
	fclose(fp);

	CString file = _T("..\\test5.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx6()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	srand(time(NULL));

	int Num;
	CString output;
	Num = rand();
	if (Num % 2 != 0) 
		output.Format(_T("Num = %d\nNum is odd"), Num);
	else
		output.Format(_T("Num = %d\nNum is even"), Num);

	AfxMessageBox(output);
}


void CMainFrame::OnEx7()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\test5.txt", "r");

	int tmp, Num =-100000, i;
	for (i = 0; i < 1000; i++)
	{
		fscanf_s(fp, "%d", &tmp, sizeof(tmp));
		if (Num < tmp)
			Num = tmp;
	}
	fclose(fp);

	CString str;
	str.Format(_T("The maximum number = %d"), Num);
	AfxMessageBox(str);
}


void CMainFrame::OnEx8()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\test5.txt", "r");

	int tmp, Num = 1000000, i;
	for (i = 0; i < 1000; i++)
	{
		fscanf_s(fp, "%d", &tmp, sizeof(tmp));
		if (Num > tmp)
			Num = tmp;
	}
	fclose(fp);

	CString str;
	str.Format(_T("The minimum number = %d"), Num);
	AfxMessageBox(str);
}


void CMainFrame::OnEx9()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\test9.txt", "w");
	int j;
	for(int i=0;i<197;i++)
	{
		if (i < 99) 
		{
			for (j = 0; j < i + 1; j++)
			{
				fprintf(fp, "%d ", j + 1);
			}
			fprintf(fp, "\n");
		}
		else 
		{
			for (j = 0; j < (197 - i);j++)
			{
				fprintf(fp, "%d ", j + 1);
			}
			fprintf(fp, "\n");
		}
	}
	fclose(fp);
	
	CString file = _T("..\\test9.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx10()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	float a = 0, b = 0, y = 0;
	FILE *fp;
	fopen_s(&fp, "..\\test10.txt", "w");
	for (int x = 0; x < 20; x++) 
	{
		if (x < 10) 
		{
			a = 1.2;
			b = 0;
		}
		else
		{
			a = 3.5;
			b = 2.1;
		}
		y = a*x + b;
		fprintf(fp, "%d %.3f %.3f %.3f\n", x, a, b, y);
	}
	fclose(fp);

	CString file = _T("..\\test10.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx11()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	srand(time(NULL));
	int Num;

	FILE *fp;
	fopen_s(&fp, "..\\test11.txt", "w");

	for (int i = 0; i < 100; i++) 
	{
		Num = rand() % 6 + 1;
		fprintf(fp, "%d\n", Num);
	}
	fclose(fp);

	CString file = _T("..\\test11.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}
