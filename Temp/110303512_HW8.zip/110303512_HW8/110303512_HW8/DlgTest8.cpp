// DlgTest8.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW8.h"
#include "DlgTest8.h"
#include "afxdialogex.h"


// CDlgTest8 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest8, CDialogEx)

CDlgTest8::CDlgTest8(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG8, pParent)
	, m_11(0)
	, m_12(0)
	, m_13(0)
	, m_21(0)
	, m_22(0)
	, m_23(0)
	, m_31(0)
	, m_32(0)
	, m_33(0)
	, m_output(0)
{

}

CDlgTest8::~CDlgTest8()
{
}

void CDlgTest8::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT5, m_11);
	DDX_Text(pDX, IDC_EDIT1, m_12);
	DDX_Text(pDX, IDC_EDIT4, m_13);
	DDX_Text(pDX, IDC_EDIT6, m_21);
	DDX_Text(pDX, IDC_EDIT3, m_22);
	DDX_Text(pDX, IDC_EDIT2, m_23);
	DDX_Text(pDX, IDC_EDIT7, m_31);
	DDX_Text(pDX, IDC_EDIT8, m_32);
	DDX_Text(pDX, IDC_EDIT9, m_33);
	DDX_Text(pDX, IDC_EDIT10, m_output);
}


BEGIN_MESSAGE_MAP(CDlgTest8, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON2, &CDlgTest8::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest8::OnBnClickedButton1)
END_MESSAGE_MAP()


// CDlgTest8 �T���B�z�`��


void CDlgTest8::OnBnClickedButton2()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	int count = 0;
	//��C
	if (m_11 == 0 && m_12 == 0 && m_13 == 0)
		count++;
	if (m_21 == 0 && m_22 == 0 && m_23 == 0)
		count++;
	if (m_31 == 0 && m_32 == 0 && m_33 == 0)
		count++;
	//����
	if (m_11 == 0 && m_21 == 0 && m_31 == 0)
		count++;
	if (m_12 == 0 && m_22 == 0 && m_32 == 0)
		count++;
	if (m_13 == 0 && m_23 == 0 && m_33 == 0)
		count++;
	//�צV
	if (m_11 == 0 && m_22 == 0 && m_33 == 0)
		count++;
	if (m_31 == 0 && m_22 == 0 && m_13 == 0)
		count++;

	m_output = count;

	UpdateData(FALSE);
}


void CDlgTest8::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	srand(time(NULL));
	UpdateData(TRUE);

	m_11 = rand() % 2;
	m_12 = rand() % 2;
	m_13 = rand() % 2;
	m_21 = rand() % 2;
	m_22 = rand() % 2;
	m_23 = rand() % 2;
	m_31 = rand() % 2;
	m_32 = rand() % 2;
	m_33 = rand() % 2;

	UpdateData(FALSE);
}
