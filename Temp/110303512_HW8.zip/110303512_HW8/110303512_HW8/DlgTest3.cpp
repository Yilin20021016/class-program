// DlgTest3.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW8.h"
#include "DlgTest3.h"
#include "afxdialogex.h"


// CDlgTest3 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest3, CDialogEx)

CDlgTest3::CDlgTest3(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG3, pParent)
	, m_input(0)
	, m_output(0)
	, m_check(1)
{

}

CDlgTest3::~CDlgTest3()
{
}

void CDlgTest3::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_input);
	DDX_Text(pDX, IDC_EDIT2, m_output);
	DDX_Radio(pDX, IDC_RADIO1, m_check);
}


BEGIN_MESSAGE_MAP(CDlgTest3, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest3::OnBnClickedButton1)
END_MESSAGE_MAP()


// CDlgTest3 �T���B�z�`��


void CDlgTest3::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	double pi = 3.141592;
	double rad = m_input;
	if (m_check == 0)
		m_output = sin(rad / 180 * pi);
	else if (m_check == 1)
		m_output = cos(rad / 180 * pi);
	else if (m_check == 2)
		m_output = tan(rad / 180 * pi);
	UpdateData(FALSE);
}
