#pragma once


// CDlgTest6 ��ܤ��

class CDlgTest6 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest6)

public:
	CDlgTest6(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest6();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG6 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	BOOL m_check;
	afx_msg void OnBnClickedButton1();
	int m_radio1;
	int m_radio2;
	afx_msg void OnBnClickedCheck1();
};
