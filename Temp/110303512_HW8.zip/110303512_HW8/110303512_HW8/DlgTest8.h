#pragma once


// CDlgTest8 ��ܤ��

class CDlgTest8 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest8)

public:
	CDlgTest8(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest8();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG8 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	int m_11;
	int m_12;
	int m_13;
	int m_21;
	int m_22;
	int m_23;
	afx_msg void OnBnClickedButton2();
	int m_31;
	int m_32;
	int m_33;
	int m_output;
	afx_msg void OnBnClickedButton1();
};
