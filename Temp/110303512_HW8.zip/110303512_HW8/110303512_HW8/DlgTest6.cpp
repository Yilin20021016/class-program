// DlgTest6.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW8.h"
#include "DlgTest6.h"
#include "afxdialogex.h"


// CDlgTest6 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest6, CDialogEx)

CDlgTest6::CDlgTest6(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG6, pParent)
	, m_check(FALSE)
	, m_radio1(1)
	, m_radio2(1)
{

}

CDlgTest6::~CDlgTest6()
{
}

void CDlgTest6::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK1, m_check);
	DDX_Radio(pDX, IDC_RADIO1, m_radio1);
	DDX_Radio(pDX, IDC_RADIO2, m_radio2);
}


BEGIN_MESSAGE_MAP(CDlgTest6, CDialogEx)
	ON_BN_CLICKED(IDC_CHECK1, &CDlgTest6::OnBnClickedCheck1)
END_MESSAGE_MAP()


// CDlgTest6 �T���B�z�`��



void CDlgTest6::OnBnClickedCheck1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);

	if (m_check) 
	{
		m_radio1 = 0;
		m_radio2 = 0;
	}
	else 
	{
		m_radio1 = 1;
		m_radio2 = 1;
	}

	UpdateData(FALSE);
}
