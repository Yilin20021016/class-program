#pragma once


// CDlgTest7 ��ܤ��

class CDlgTest7 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest7)

public:
	CDlgTest7(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest7();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG7 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:

	afx_msg void OnBnClickedButton1();
	int m_radio1;
	int m_radio2;
	int m_radio3;
	int m_radio4;
	afx_msg void OnBnClickedButton2();
};
