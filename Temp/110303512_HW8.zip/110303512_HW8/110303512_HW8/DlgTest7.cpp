// DlgTest7.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW8.h"
#include "DlgTest7.h"
#include "afxdialogex.h"


// CDlgTest7 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest7, CDialogEx)

CDlgTest7::CDlgTest7(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG7, pParent)
	, m_radio1(1)
	, m_radio2(1)
	, m_radio3(1)
	, m_radio4(1)
{

}

CDlgTest7::~CDlgTest7()
{
}

void CDlgTest7::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_RADIO1, m_radio1);
	DDX_Radio(pDX, IDC_RADIO2, m_radio2);
	DDX_Radio(pDX, IDC_RADIO3, m_radio3);
	DDX_Radio(pDX, IDC_RADIO4, m_radio4);
}


BEGIN_MESSAGE_MAP(CDlgTest7, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest7::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CDlgTest7::OnBnClickedButton2)
END_MESSAGE_MAP()


// CDlgTest7 �T���B�z�`��


void CDlgTest7::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	
	if (m_radio1 == 0 || m_radio4 == 0) 
	{
		m_radio1 = 0;
		m_radio4 = 0;
	}

	if (m_radio2 == 0 || m_radio3 == 0)
	{
		m_radio2 = 0;
		m_radio3 = 0;
	}

	UpdateData(FALSE);
}


void CDlgTest7::OnBnClickedButton2()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);

	m_radio1 = 1;
	m_radio2 = 1;
	m_radio3 = 1;
	m_radio4 = 1;

	UpdateData(FALSE);
}
