// DlgTest5.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW8.h"
#include "DlgTest5.h"
#include "afxdialogex.h"


// CDlgTest5 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest5, CDialogEx)

CDlgTest5::CDlgTest5(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG5, pParent)
	, m_input(0)
	, m_output(0)
	, m_check1(0)
	, m_check2(0)
{

}

CDlgTest5::~CDlgTest5()
{
}

void CDlgTest5::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_input);
	DDX_Text(pDX, IDC_EDIT2, m_output);
	DDX_Radio(pDX, IDC_RADIO1, m_check1);
	DDX_Radio(pDX, IDC_RADIO3, m_check2);
}


BEGIN_MESSAGE_MAP(CDlgTest5, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest5::OnBnClickedButton1)
END_MESSAGE_MAP()


// CDlgTest5 �T���B�z�`��


void CDlgTest5::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	double pi = 3.141592;
	double rad = m_input;

	if (m_check1 == 0)
		rad = rad / 180 * pi;

	if (m_check2 == 0)
		m_output = sin(rad);
	else if (m_check2 == 1)
		m_output = cos(rad);
	else if (m_check2 == 2)
		m_output = tan(rad);

	UpdateData(FALSE);
}
