#pragma once


// CDlgTest2 ��ܤ��

class CDlgTest2 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest2)

public:
	CDlgTest2(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest2();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG2 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	double m_input;
	double m_output;
	int m_check;
	afx_msg void OnBnClickedButton1();
};
