// DlgTest2.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW8.h"
#include "DlgTest2.h"
#include "afxdialogex.h"
#include "Math.h"


// CDlgTest2 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest2, CDialogEx)

CDlgTest2::CDlgTest2(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG2, pParent)
	, m_input(0)
	, m_output(0)
	, m_check(0)
{

}

CDlgTest2::~CDlgTest2()
{
}

void CDlgTest2::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_input);
	DDX_Text(pDX, IDC_EDIT2, m_output);
	DDX_Radio(pDX, IDC_RADIO1, m_check);
}


BEGIN_MESSAGE_MAP(CDlgTest2, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest2::OnBnClickedButton1)
END_MESSAGE_MAP()


// CDlgTest2 �T���B�z�`��


void CDlgTest2::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	double pi = 3.141592;
	double rad = m_input;
	if (m_check == 0)
		m_output = sin(rad / 180 * pi);
	else if (m_check == 1)
		m_output = cos(rad / 180 * pi);
	else if (m_check == 2)
		m_output = tan(rad / 180 * pi);
	UpdateData(FALSE);
}
