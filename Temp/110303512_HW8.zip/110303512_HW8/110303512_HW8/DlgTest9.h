#pragma once


// CDlgTest9 ��ܤ��

class CDlgTest9 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest9)

public:
	CDlgTest9(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest9();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG9 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	int m_radio1;
	int m_radio2;
	int m_radio3;
	int m_radio4;
	int m_radio5;
	int m_radio6;
	int m_radio7;
	int m_radio8;
	int m_radio9;
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
};
