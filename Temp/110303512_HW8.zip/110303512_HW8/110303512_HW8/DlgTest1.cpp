// DlgTest1.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW8.h"
#include "DlgTest1.h"
#include "afxdialogex.h"
#include <vector>
using namespace std;


// CDlgTest1 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest1, CDialogEx)

CDlgTest1::CDlgTest1(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, m_output(0)
	, m_input(0)
{

}

CDlgTest1::~CDlgTest1()
{
}

void CDlgTest1::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_output);
	DDX_Text(pDX, IDC_EDIT2, m_input);
	DDV_MinMaxInt(pDX, m_input, 1, 6);
}


BEGIN_MESSAGE_MAP(CDlgTest1, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest1::OnBnClickedButton1)
END_MESSAGE_MAP()


// CDlgTest1 �T���B�z�`��


void CDlgTest1::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	srand(time(NULL));
	int num = 100000;
	vector<int> A;
	int i;
	for (i = 0; i < num; i++)
	{
		int tmp = rand() % 6 + 1;
		A.push_back(tmp);
	}

	int count = 0;
	for (i = 0; i < num; i++)
	{
		if (A[i] == m_input)
			count++;
	}

	m_output = (double)count / num;
	i = 0;
	while (i < A.size()) 
	{
		if (A[i] == 2 || A[i] == 3) 
		{
			A.erase(A.begin() + i);
		}
		else 
		{
			i++;
		}
	}
	CString o2;
	o2.Format(_T("%d"), A.size());
	AfxMessageBox(o2);

	UpdateData(FALSE);
}
