// DlgTest9.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW8.h"
#include "DlgTest9.h"
#include "afxdialogex.h"


// CDlgTest9 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest9, CDialogEx)

CDlgTest9::CDlgTest9(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG9, pParent)
	, m_radio1(-1)
	, m_radio2(-1)
	, m_radio3(-1)
	, m_radio4(-1)
	, m_radio5(-1)
	, m_radio6(-1)
	, m_radio7(-1)
	, m_radio8(-1)
	, m_radio9(-1)
{

}

CDlgTest9::~CDlgTest9()
{
}

void CDlgTest9::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_RADIO1, m_radio1);
	DDX_Radio(pDX, IDC_RADIO2, m_radio2);
	DDX_Radio(pDX, IDC_RADIO3, m_radio3);
	DDX_Radio(pDX, IDC_RADIO4, m_radio4);
	DDX_Radio(pDX, IDC_RADIO5, m_radio5);
	DDX_Radio(pDX, IDC_RADIO6, m_radio6);
	DDX_Radio(pDX, IDC_RADIO7, m_radio7);
	DDX_Radio(pDX, IDC_RADIO8, m_radio8);
	DDX_Radio(pDX, IDC_RADIO9, m_radio9);
}


BEGIN_MESSAGE_MAP(CDlgTest9, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest9::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CDlgTest9::OnBnClickedButton2)
END_MESSAGE_MAP()


// CDlgTest9 �T���B�z�`��


void CDlgTest9::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);

	if (m_radio1 + m_radio2 + m_radio3 + m_radio4 + m_radio5 + m_radio6 + m_radio7 + m_radio8 + m_radio9 == -6) 
	{
		if (m_radio1 == 0 && m_radio2 == 0 && m_radio3 == 0 || m_radio4 == 0 && m_radio5 == 0 && m_radio6 == 0 || m_radio7 == 0 && m_radio8 == 0 && m_radio9 == 0) 
		{
			AfxMessageBox(_T("This is a horizontal line."));
		}
		else if(m_radio1 == 0 && m_radio4 == 0 && m_radio7 == 0 || m_radio2 == 0 && m_radio5 == 0 && m_radio8 == 0 || m_radio3 == 0 && m_radio6 == 0 && m_radio9 == 0)
		{
			AfxMessageBox(_T("This is a vertical line."));
		}
		else if (m_radio1 == 0 && m_radio5 == 0 && m_radio9 == 0 || m_radio3 == 0 && m_radio5 == 0 && m_radio7 == 0)
		{
			AfxMessageBox(_T("This is a diagonal line."));
		}
		else 
		{
			AfxMessageBox(_T("There is no line."));
		}
	}
	else 
	{
		AfxMessageBox(_T("PLEASE SET 3 RADIO"));
		m_radio1 = -1;
		m_radio2 = -1;
		m_radio3 = -1;
		m_radio4 = -1;
		m_radio5 = -1;
		m_radio6 = -1;
		m_radio7 = -1;
		m_radio8 = -1;
		m_radio9 = -1;
	}

	UpdateData(FALSE);
}


void CDlgTest9::OnBnClickedButton2()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);

	m_radio1 = -1;
	m_radio2 = -1;
	m_radio3 = -1;
	m_radio4 = -1;
	m_radio5 = -1;
	m_radio6 = -1;
	m_radio7 = -1;
	m_radio8 = -1;
	m_radio9 = -1;

	UpdateData(FALSE);
}
