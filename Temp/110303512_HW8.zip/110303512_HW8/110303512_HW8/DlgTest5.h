#pragma once


// CDlgTest5 ��ܤ��

class CDlgTest5 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest5)

public:
	CDlgTest5(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest5();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG5 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	double m_input;
	double m_output;
	int m_check1;
	int m_check2;
	afx_msg void OnBnClickedButton1();
};
