// DlgTest4.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW8.h"
#include "DlgTest4.h"
#include "afxdialogex.h"


// CDlgTest4 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest4, CDialogEx)

CDlgTest4::CDlgTest4(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG4, pParent)
	, m_input(0)
	, m_check(0)
	, m_output(_T("0"))
{

}

CDlgTest4::~CDlgTest4()
{
}

void CDlgTest4::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_input);
	DDX_Radio(pDX, IDC_RADIO1, m_check);
	DDX_Text(pDX, IDC_EDIT2, m_output);
}


BEGIN_MESSAGE_MAP(CDlgTest4, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest4::OnBnClickedButton1)
END_MESSAGE_MAP()


// CDlgTest4 �T���B�z�`��


void CDlgTest4::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	double pi = 3.141592;
	double rad = m_input,tmp=0;
	if (m_check == 0)
		tmp = sin(rad / 180 * pi);
	else if (m_check == 1)
		tmp = cos(rad / 180 * pi);
	else if (m_check == 2)
		tmp = tan(rad / 180 * pi);

	CString str;
	str.Format(_T("%.2f"), tmp);
	m_output = str;
	UpdateData(FALSE);
}
