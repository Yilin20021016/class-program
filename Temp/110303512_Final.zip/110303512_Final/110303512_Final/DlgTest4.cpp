// DlgTest4.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_Final.h"
#include "DlgTest4.h"
#include "afxdialogex.h"
#include "vector"
using namespace std;


// CDlgTest4 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest4, CDialogEx)

CDlgTest4::CDlgTest4(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG3, pParent)
	, m_id(0)
	, m_hw(0)
	, m_mid(0)
	, m_final(0)
	, m_sc(0)
{

}

CDlgTest4::~CDlgTest4()
{
}

void CDlgTest4::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT2, m_id);
	DDX_Text(pDX, IDC_EDIT3, m_hw);
	DDX_Text(pDX, IDC_EDIT5, m_mid);
	DDX_Text(pDX, IDC_EDIT1, m_final);
	DDX_Text(pDX, IDC_EDIT4, m_sc);
}

double CDlgTest4::caculate(int Hw, int Mid, int Fin)
{
	double a = Hw, b = Mid, c = Fin;
	double output = 0.3*a + 0.35*b + 0.35*c;
	return(output);
}


BEGIN_MESSAGE_MAP(CDlgTest4, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON4, &CDlgTest4::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest4::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON3, &CDlgTest4::OnBnClickedButton3)
END_MESSAGE_MAP()


// CDlgTest4 �T���B�z�`��

StudentInfo::StudentInfo()
{
	ID = 0;
	hw = 0;
	mid = 0;
	fin = 0;
	sc = 0;
}


void CDlgTest4::OnBnClickedButton4()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	StudentInfo data;
	FILE *fp;
	fopen_s(&fp, "..\\Final_ex4.txt", "a");

	UpdateData(TRUE);

	data.ID = m_id;
	data.hw= m_hw;
	data.mid = m_mid;
	data.fin = m_final;
	m_sc = caculate(m_hw, m_mid, m_final);
	data.sc = m_sc;

	fprintf(fp, "%d\t%d\t%d\t%d\t%.2f\n", data.ID, data.hw, data.mid, data.fin, data.sc);
	fclose(fp);
	
	UpdateData(FALSE);
	
}


void CDlgTest4::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	CString file = _T("..\\Final_ex4.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CDlgTest4::OnBnClickedButton3()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\Final_ex4.txt", "r");

	vector <StudentInfo>student;
	
	long a; int b, c, d; double e;
	StudentInfo tmp;

	while (fscanf_s(fp, "%d%d%d%d%lf", &a, &b, &c, &d, &e) != EOF) 
	{
		tmp.ID = a; tmp.hw = b; tmp.mid = c; tmp.fin = d; tmp.sc = e;
		student.push_back(tmp);
	}

	fclose(fp);

	for (int i = 0; i < student.size()-1; i++) 
	{
		for (int j = 0; j < i; j++)
		{
			if (student[j].sc < student[j + 1].sc) 
			{
				tmp = student[j];
				student[j] = student[j + 1];
				student[j + 1] = tmp;
			}
		}
	}

	fopen_s(&fp, "..\\Final_ex4_arrange.txt", "w");

	for (int i = 0; i < student.size(); i++) 
	{
		fprintf(fp, "%d\t%d\t%d\t%d\t%.2f\n", student[i].ID, student[i].hw, student[i].mid, student[i].fin, student[i].sc);
	}

	fclose(fp);

	CString file = _T("..\\Final_ex4_arrange.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);

}
