// DlgTest1.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_Final.h"
#include "DlgTest1.h"
#include "afxdialogex.h"


// CDlgTest1 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest1, CDialogEx)

CDlgTest1::CDlgTest1(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, m_p(0)
	, m_c(0)
	, m_ps(0)
	, m_cs(0)
{

}

CDlgTest1::~CDlgTest1()
{
}

void CDlgTest1::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_RADIO1, m_p);
	DDX_Radio(pDX, IDC_RADIO4, m_c);
	DDX_Text(pDX, IDC_EDIT1, m_ps);
	DDX_Text(pDX, IDC_EDIT2, m_cs);
}


BEGIN_MESSAGE_MAP(CDlgTest1, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest1::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CDlgTest1::OnBnClickedButton2)
END_MESSAGE_MAP()


// CDlgTest1 �T���B�z�`��


void CDlgTest1::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	srand(time(NULL));
	UpdateData(TRUE);
	
	m_c = rand() % 3;
	if (m_p == m_c) 
	{
	}
	else
	{
		if ((m_p == 0 && m_c == 1) || (m_p == 1 && m_c == 2) || (m_p == 2 && m_c == 0))
		{
			m_cs++;
		}
		else
		{
			m_ps++;
		}
	}
	UpdateData(FALSE);
}


void CDlgTest1::OnBnClickedButton2()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	m_ps = 0;
	m_cs = 0;
	UpdateData(FALSE);
}
