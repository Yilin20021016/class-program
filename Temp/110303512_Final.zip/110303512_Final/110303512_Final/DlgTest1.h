#pragma once


// CDlgTest1 ��ܤ��

class CDlgTest1 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest1)

public:
	CDlgTest1(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest1();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	int m_p;
	int m_c;
	int m_ps;
	int m_cs;
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
};
