#pragma once


// CDlgTest4 ��ܤ��

class StudentInfo 
{
public:
	StudentInfo();

	long ID;
	int hw;
	int mid;
	int fin;
	double sc;
};

class CDlgTest4 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest4)

public:
	CDlgTest4(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest4();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG3 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	long m_id;
	int m_hw;
	int m_mid;
	int m_final;
	double m_sc;
	double caculate(int Hw, int Mid, int Fin);
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton3();
};
