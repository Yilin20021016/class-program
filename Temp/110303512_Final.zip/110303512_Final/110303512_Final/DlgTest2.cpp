// DlgTest2.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_Final.h"
#include "DlgTest2.h"
#include "afxdialogex.h"
#include "math.h"


// CDlgTest2 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest2, CDialogEx)

CDlgTest2::CDlgTest2(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG2, pParent)
	, m_height(0)
	, m_weight(0)
	, m_bmi(0)
{

}

CDlgTest2::~CDlgTest2()
{
}

void CDlgTest2::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_height);
	DDX_Text(pDX, IDC_EDIT2, m_weight);
	DDX_Text(pDX, IDC_EDIT3, m_bmi);
}


BEGIN_MESSAGE_MAP(CDlgTest2, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest2::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CDlgTest2::OnBnClickedButton2)
END_MESSAGE_MAP()


// CDlgTest2 �T���B�z�`��

BMIInfo::BMIInfo()
{
	Weight = 0;
	Height = 0;
	BMI = 0;
}

void BMIInfo::ComputeBMI()
{
	BMI = Weight / (pow(Height / 100, 2));
}



void CDlgTest2::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	BMIInfo data;
	UpdateData(TRUE);

	data.Height = m_height;
	data.Weight = m_weight;
	data.ComputeBMI();
	m_bmi = data.BMI;

	BMIData.push_back(data);

	UpdateData(FALSE);
}


void CDlgTest2::OnBnClickedButton2()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	CString title = _T("�s��\t����\t�魫\tBMI\n");
	CString str = _T(""), tmp;
	for (int i = 0; i < BMIData.size(); i++) 
	{
		tmp.Format(_T("%d\t%.2f\t%.2f\t%.2f\n"), i, BMIData[i].Height, BMIData[i].Weight, BMIData[i].BMI);
		str += tmp;
	}
	AfxMessageBox(title + str);
}
