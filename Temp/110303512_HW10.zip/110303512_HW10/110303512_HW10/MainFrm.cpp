
// MainFrm.cpp : CMainFrame ���O����@
//

#include "stdafx.h"
#include "110303512_HW10.h"

#include "MainFrm.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWndEx)

const int  iMaxUserToolbars = 10;
const UINT uiFirstUserToolBarId = AFX_IDW_CONTROLBAR_FIRST + 40;
const UINT uiLastUserToolBarId = uiFirstUserToolBarId + iMaxUserToolbars - 1;

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWndEx)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_VIEW_CUSTOMIZE, &CMainFrame::OnViewCustomize)
	ON_REGISTERED_MESSAGE(AFX_WM_CREATETOOLBAR, &CMainFrame::OnToolbarCreateNew)
	ON_COMMAND_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnApplicationLook)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnUpdateApplicationLook)
	ON_COMMAND(IDD_EX1, &CMainFrame::OnEx1)
	ON_COMMAND(IDD_EX2, &CMainFrame::OnEx2)
	ON_COMMAND(IDD_EX3, &CMainFrame::OnEx3)
	ON_COMMAND(IDD_EX4, &CMainFrame::OnEx4)
	ON_COMMAND(IDD_EX5, &CMainFrame::OnEx5)
	ON_COMMAND(IDD_EX6, &CMainFrame::OnEx6)
	ON_COMMAND(IDD_EX7, &CMainFrame::OnEx7)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // ���A�C���ܾ�
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

// CMainFrame �غc/�Ѻc

CMainFrame::CMainFrame()
{
	// TODO: �b���[�J������l�Ƶ{���X
	theApp.m_nAppLook = theApp.GetInt(_T("ApplicationLook"), ID_VIEW_APPLOOK_VS_2008);
}
//Ex1
double CMainFrame::Distance2D(int X1, int Y1, int X2, int Y2)
{
	double distance = sqrt(pow(abs(X1 - X2), 2) + pow(abs(Y1 - Y2), 2));
	return distance;
}
//Ex2
void CMainFrame::ComputePoint(double T, double &X, double &Y, double &Z) 
{
	X = 5 * pow(T, 2) + 3 * T + 1;
	Y = 7 * T - 3;
	Z = 2 * pow(T, 2) - 3 * T - 2;
}

double CMainFrame::Distance3D(double X1, double Y1, double Z1, double X2, double Y2, double Z2) 
{
	double Distance;
	Distance = sqrt(pow(abs(X1 - X2), 2) + pow(abs(Y1 - Y2), 2) + pow(abs(Z1 - Z2), 2));
	return Distance;
}
//Ex3
void CMainFrame::ComputeUV(vector<double> Pt1, vector<double> Pt2, vector<double> &Vunit) 
{
	double Length = sqrt(pow(abs(Pt1[0] - Pt2[0]), 2) + pow(abs(Pt1[1] - Pt2[1]), 2) + pow(abs(Pt1[2] - Pt2[2]), 2));
	double Ux = (Pt2[0] - Pt1[0]) / Length;
	double Uy = (Pt2[1] - Pt1[1]) / Length;
	double Uz = (Pt2[2] - Pt1[2]) / Length;
	Vunit[0] = Ux;
	Vunit[1] = Uy;
	Vunit[2] = Uz;
}
//Ex4
bool CMainFrame::ComputeUintVector(vector<double> Pt1, vector<double> Pt2, vector<double> &Vunit, double &Length) 
{
	Length = sqrt(pow(abs(Pt1[0] - Pt2[0]), 2) + pow(abs(Pt1[1] - Pt2[1]), 2) + pow(abs(Pt1[2] - Pt2[2]), 2));
	if (Length < 0.1) 
	{
		return true;
	}
	else 
	{
		double Ux = (Pt2[0] - Pt1[0]) / Length;
		double Uy = (Pt2[1] - Pt1[1]) / Length;
		double Uz = (Pt2[2] - Pt1[2]) / Length;
		Vunit[0] = Ux;
		Vunit[1] = Uy;
		Vunit[2] = Uz;

		return false;
	}
}
//Ex5
bool CMainFrame::PrimeCheck(int Num)
{
	for (int i = 2; i < Num; i++)
		if (Num%i == 0)
			return false;
	return true;
}
//Ex6
void CMainFrame::EvaluateCoefficient(vector <double>X, vector <double>Y, double &A, double &B) 
{
	// X_bar
	double Sum_X = 0;
	for (int i = 0; i < X.size(); i++) 
	{
		Sum_X += X[i];
	}
	double X_bar = Sum_X / X.size();

	//Y_bar
	double Sum_Y = 0;
	for (int i = 0; i < Y.size(); i++)
	{
		Sum_Y += Y[i];
	}
	double Y_bar = Sum_Y / Y.size();

	//B
	double Sum_up = 0, Sum_down = 0;
	for (int i = 0; i < X.size(); i++) 
	{
		Sum_up += (X[i] - X_bar)*(Y[i] - Y_bar);
		Sum_down += pow(X[i] - X_bar, 2);
	}
	B = Sum_up / Sum_down;

	//A
	A = Y_bar - B*X_bar;
}
//Ex7
void CMainFrame::CUV(vector <double>Line1, vector <double>Line2, vector <double>&Uv1, vector <double>&Uv2, double T)
{
	double Length1 = sqrt(pow(abs(Line1[0] - Line1[2]), 2) + pow(abs(Line1[1] - Line1[3]), 2));
	double Ux = (Line1[2] - Line1[0]) / Length1;
	double Uy = (Line1[3] - Line1[1]) / Length1;
	Uv1[0] = Ux;
	Uv1[1] = Uy;

	double Length2 = sqrt(pow(abs(Line2[0] - Line2[2]), 2) + pow(abs(Line2[1] - Line2[3]), 2));
	Ux = (Line2[2] - Line2[0]) / Length2;
	Uy = (Line2[3] - Line2[1]) / Length2;
	Uv2[0] = Ux;
	Uv2[1] = Uy;
}

void CMainFrame::side(vector<double>& x1, vector<double>& y1, vector<double>& x2, vector<double>& y2)
{
	bool flag = false;
	CString str, str2;
	for (int i = 0; i < 99; i++)
	{
		if (x1[i] >= x2[0] && x1[i + 1] <= x2[99])
		{
			if (y1[i] >= y2[(int)x1[i]] && y1[i + 1] <= y2[(int)x1[i + 1]] || y1[i] <= y2[(int)x1[i]] && y1[i + 1] >= y2[(int)x1[i + 1]])
			{

				str2.Format(_T("intresection at:t=%d~%d\n"), i / 10 * 10, i / 10 + 10);
				str += str2;
				flag = true;
			}
		}
	}
	if (!flag)
	{
		str.Format(_T("There is no intersection"));
	}

	AfxMessageBox(str);
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	BOOL bNameValid;

	if (!m_wndMenuBar.Create(this))
	{
		TRACE0("�L�k�إߥ\����C\n");
		return -1;      // �L�k�إ�
	}

	m_wndMenuBar.SetPaneStyle(m_wndMenuBar.GetPaneStyle() | CBRS_SIZE_DYNAMIC | CBRS_TOOLTIPS | CBRS_FLYBY);

	// ����\����C�b�ҥήɨ��o�J�I
	CMFCPopupMenu::SetForceMenuFocus(FALSE);

	// �إߦ���ج[�u�@�Ϫ��˵�
	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW, CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	{
		TRACE0("�L�k�إ��˵�����\n");
		return -1;
	}

	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(theApp.m_bHiColorIcons ? IDR_MAINFRAME_256 : IDR_MAINFRAME))
	{
		TRACE0("�L�k�إߤu��C\n");
		return -1;      // �L�k�إ�
	}

	CString strToolBarName;
	bNameValid = strToolBarName.LoadString(IDS_TOOLBAR_STANDARD);
	ASSERT(bNameValid);
	m_wndToolBar.SetWindowText(strToolBarName);

	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);
	m_wndToolBar.EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);

	// ���\�ϥΪ̩w�q���u��C�@�~: 
	InitUserToolbars(NULL, uiFirstUserToolBarId, uiLastUserToolBarId);

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("�L�k�إߪ��A�C\n");
		return -1;      // �L�k�إ�
	}
	m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT));

	// TODO: �p�G���Ʊ�u��C�M�\����C���i���n�A�ЧR���o 5 ��
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndMenuBar);
	DockPane(&m_wndToolBar);


	// �ҥ� Visual Studio 2005 �˦����n�����欰
	CDockingManager::SetDockingMode(DT_SMART);
	// �ҥ� Visual Studio 2005 �˦����n�����۰����æ欰
	EnableAutoHidePanes(CBRS_ALIGN_ANY);
	// �ھګ���ȳ]�w��ı�ƺ޲z���M�˦�
	OnApplicationLook(theApp.m_nAppLook);

	// �ҥΤu��C�M���n�����\������N
	EnablePaneMenu(TRUE, ID_VIEW_CUSTOMIZE, strCustomize, ID_VIEW_TOOLBAR);

	// �ҥΧֳt (Alt+�즲) �u��C�ۭq
	CMFCToolBar::EnableQuickCustomization();

	if (CMFCToolBar::GetUserImages() == NULL)
	{
		// ���J�ϥΪ̩w�q���u��C�v��
		if (m_UserImages.Load(_T(".\\UserImages.bmp")))
		{
			CMFCToolBar::SetUserImages(&m_UserImages);
		}
	}

	// �ҥΥ\����ӤH�� (�̪�ϥΪ��R�O)
	// TODO: �w�q�z�ۤv���򥻩R�O�A�T�w�C�ӤU�Ԧ��\������ܤ֦��@�Ӱ򥻩R�O�C
	CList<UINT, UINT> lstBasicCommands;

	lstBasicCommands.AddTail(ID_APP_EXIT);
	lstBasicCommands.AddTail(ID_EDIT_CUT);
	lstBasicCommands.AddTail(ID_EDIT_PASTE);
	lstBasicCommands.AddTail(ID_EDIT_UNDO);
	lstBasicCommands.AddTail(ID_APP_ABOUT);
	lstBasicCommands.AddTail(ID_VIEW_STATUS_BAR);
	lstBasicCommands.AddTail(ID_VIEW_TOOLBAR);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2003);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_VS_2005);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_BLUE);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_SILVER);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_BLACK);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_AQUA);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_WINDOWS_7);

	CMFCToolBar::SetBasicCommands(lstBasicCommands);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWndEx::PreCreateWindow(cs) )
		return FALSE;
	// TODO: �b���g�ѭק� CREATESTRUCT cs 
	// �F��ק�������O�μ˦����ت�

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);
	return TRUE;
}

// CMainFrame �E�_

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWndEx::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWndEx::Dump(dc);
}
#endif //_DEBUG


// CMainFrame �T���B�z�`��

void CMainFrame::OnSetFocus(CWnd* /*pOldWnd*/)
{
	// ��e�J�I���˵�����
	m_wndView.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// ���˵��b�R�O���Ĥ@�ӵѨ�
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// �_�h�A����w�]���B�z
	return CFrameWndEx::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void CMainFrame::OnViewCustomize()
{
	CMFCToolBarsCustomizeDialog* pDlgCust = new CMFCToolBarsCustomizeDialog(this, TRUE /* ���y�\��� */);
	pDlgCust->EnableUserDefinedToolbars();
	pDlgCust->Create();
}

LRESULT CMainFrame::OnToolbarCreateNew(WPARAM wp,LPARAM lp)
{
	LRESULT lres = CFrameWndEx::OnToolbarCreateNew(wp,lp);
	if (lres == 0)
	{
		return 0;
	}

	CMFCToolBar* pUserToolbar = (CMFCToolBar*)lres;
	ASSERT_VALID(pUserToolbar);

	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
	return lres;
}

void CMainFrame::OnApplicationLook(UINT id)
{
	CWaitCursor wait;

	theApp.m_nAppLook = id;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_WIN_2000:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManager));
		break;

	case ID_VIEW_APPLOOK_OFF_XP:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOfficeXP));
		break;

	case ID_VIEW_APPLOOK_WIN_XP:
		CMFCVisualManagerWindows::m_b3DTabsXPTheme = TRUE;
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));
		break;

	case ID_VIEW_APPLOOK_OFF_2003:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2003));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_VS_2005:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2005));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_VS_2008:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2008));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_WINDOWS_7:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows7));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	default:
		switch (theApp.m_nAppLook)
		{
		case ID_VIEW_APPLOOK_OFF_2007_BLUE:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_LunaBlue);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_BLACK:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_ObsidianBlack);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_SILVER:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Silver);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_AQUA:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Aqua);
			break;
		}

		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2007));
		CDockingManager::SetDockingMode(DT_SMART);
	}

	RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE | RDW_UPDATENOW | RDW_FRAME | RDW_ERASE);

	theApp.WriteInt(_T("ApplicationLook"), theApp.m_nAppLook);
}

void CMainFrame::OnUpdateApplicationLook(CCmdUI* pCmdUI)
{
	pCmdUI->SetRadio(theApp.m_nAppLook == pCmdUI->m_nID);
}


BOOL CMainFrame::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd* pParentWnd, CCreateContext* pContext) 
{
	// �����O�q�ƹ�ڧ@�~

	if (!CFrameWndEx::LoadFrame(nIDResource, dwDefaultStyle, pParentWnd, pContext))
	{
		return FALSE;
	}


	// �ҥΩҦ��ϥΪ̤u��C���ۭq���s
	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	for (int i = 0; i < iMaxUserToolbars; i ++)
	{
		CMFCToolBar* pUserToolbar = GetUserToolBarByIndex(i);
		if (pUserToolbar != NULL)
		{
			pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
		}
	}

	return TRUE;
}



void CMainFrame::OnEx1()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\output1.txt", "w");
	fprintf(fp, "t\tx1\ty1\tx2\ty2\tdistance\n");
	for (int t = 0; t < 100; t++) 
	{
		int x1 = 5 * pow(t, 2) + 3 * t + 1;
		int y1 = 7 * t - 3;
		int x2 = t;
		int y2 = 2 * t - 1;

		double ans = Distance2D(x1, y1, x2, y2);
		fprintf(fp, "%d\t%d\t%d\t%d\t%d\t%.2f\n", t, x1, y1, x2, y2, ans);
	}

	fclose(fp);
	CString file = _T("..\\output1.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx2()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	FILE *fp;
	fopen_s(&fp, "..\\output2.txt", "w");
	fprintf(fp, "t\tx\ty\tz\tDistance\n");

	double x1 = 0, y1 = 0, z1 = 0, x2 = 0, y2 = 0, z2 = 0;
	double distance = 0;

	for (double t = 0; t < 20; t += 0.2) 
	{
		ComputePoint(t, x1, y1, z1);
		ComputePoint(t + 0.2, x2, y2, z2);
		distance = Distance3D(x1, y1, z1, x2, y2, z2);
		fprintf(fp, "%g\t%.2f\t%.2f\t%.2f\t%.2f\n", t, x1, y1, z1, distance);
	}
	
	fclose(fp);

	CString file = _T("..\\output2.txt");
	ShellExecute(NULL, _T("open"), file, NULL, NULL, SW_SHOW);
}


void CMainFrame::OnEx3()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	vector<double> pt1 = { 1,1,1 }, pt2 = { 3,4,5 }, vunit(3, 0);
	ComputeUV(pt1,pt2,vunit);
	CString o2;
	o2.Format(_T("Uint Vector = ( %.2f,%.2f,%.2f )"), vunit[0], vunit[1], vunit[2]);
	AfxMessageBox(o2);
}


void CMainFrame::OnEx4()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	vector<double> pt1 = { 1,1,1 }, pt2 = { 2,2,2 }, vunit(3, 0);//Vunit = { 0,0,0 }
	double Distance;
	bool IsOverlap = ComputeUintVector(pt1, pt2, vunit, Distance);
	if (IsOverlap)
	{
		AfxMessageBox(_T("Pt1 and Pt2 are overlaping."));
	}
	else 
	{
		CString o1;
		o1.Format(_T("Pt1 and Pt2 are NOT overlaping,\nvunit = ( %.2f,%.2f,%.2f )\nDistance = %.2f\n"), vunit[0], vunit[1], vunit[2], Distance);
		AfxMessageBox(o1);
	}
}


void CMainFrame::OnEx5()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	srand(time(NULL));
	int num = rand();
	CString o2;
	if (PrimeCheck(num)) 
	{
		o2.Format(_T("%d is a prime factor."), num);
	}
	else 
	{
		vector <int>factor;
		int i = 2, tmp = num;
		while (i <= tmp) 
		{
			if (tmp%i == 0)
			{
				factor.push_back(i);
				tmp /= i;
			}
			else 
			{
				i++;
			}
		}
		o2.Format(_T("%d is NOT a prime factor.\nIt's prime factors is"), num);
		CString str;
		for (int j = 0; j < factor.size(); j++)
		{
			str.Format(_T(" %d"), factor[j]);
			o2 += str;
		}
	}
	AfxMessageBox(o2);
}


void CMainFrame::OnEx6()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	srand(time(NULL));
	vector <double>x;
	vector <double>y;
	double a, b;
	for (int t = 0; t < 21; t++) 
	{
		x.push_back(t);
		y.push_back(3 * t + 5 + 0.02*(rand()%21-10));
	}
	EvaluateCoefficient(x, y, a, b);
	CString o2;
	o2.Format(_T("a = %f\nb = %f"), a, b);
	AfxMessageBox(o2);
}


void CMainFrame::OnEx7()
{
	// TODO: �b���[�J�z���R�O�B�z�`���{���X
	vector<double> x1, y1;
	vector<double> x2, y2;
	for (int t = 0; t < 100; t++)
	{
		double x = 5 * pow(t, 2) + 3 * t + 1;
		double y = 7 * t - 3;
		x1.push_back(x);
		y1.push_back(y);
		x = t;
		y = 2 * t - 1;
		x2.push_back(x);
		y2.push_back(y);
	}

	side(x1, y1, x2, y2);
}
