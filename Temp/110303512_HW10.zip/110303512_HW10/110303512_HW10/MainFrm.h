
// MainFrm.h : CMainFrame ���O������
//

#pragma once
#include "ChildView.h"
#include <vector>
using namespace std;

class CMainFrame : public CFrameWndEx
{
	
public:
	CMainFrame();
protected: 
	DECLARE_DYNAMIC(CMainFrame)

// �ݩ�
public:
	//Ex1
	double Distance2D(int X1, int Y1, int X2, int Y2);
	//Ex2
	void ComputePoint(double T, double &X, double &Y, double &Z);
	double Distance3D(double X1, double Y1, double Z1, double X2, double Y2, double Z2);
	//Ex3
	void ComputeUV(vector<double> Pt1, vector<double> Pt2, vector<double> &Vunit);
	//Ex4
	bool ComputeUintVector(vector<double> Pt1, vector<double> Pt2, vector<double> &Vunit, double &Length);
	//Ex5
	bool PrimeCheck(int Num);
	//Ex6
	void EvaluateCoefficient(vector <double>X, vector <double>Y, double &A, double &B);
	//Ex7
	void CUV(vector <double>Line1, vector <double>Line2, vector <double>&Uv1, vector <double>&Uv2, double T);
	void side(vector<double>& x1, vector<double>& y1, vector<double>& x2, vector<double>& y2);

// �@�~
public:

// �мg
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	virtual BOOL LoadFrame(UINT nIDResource, DWORD dwDefaultStyle = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, CWnd* pParentWnd = NULL, CCreateContext* pContext = NULL);

// �{���X��@
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // ����C���O������
	CMFCMenuBar       m_wndMenuBar;
	CMFCToolBar       m_wndToolBar;
	CMFCStatusBar     m_wndStatusBar;
	CMFCToolBarImages m_UserImages;
	CChildView    m_wndView;

// ���ͪ��T�������禡
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSetFocus(CWnd *pOldWnd);
	afx_msg void OnViewCustomize();
	afx_msg LRESULT OnToolbarCreateNew(WPARAM wp, LPARAM lp);
	afx_msg void OnApplicationLook(UINT id);
	afx_msg void OnUpdateApplicationLook(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnEx1();
	afx_msg void OnEx2();
	afx_msg void OnEx3();
	afx_msg void OnEx4();
	afx_msg void OnEx5();
	afx_msg void OnEx6();
	afx_msg void OnEx7();
};


