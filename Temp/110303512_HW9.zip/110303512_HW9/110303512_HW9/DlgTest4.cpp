// DlgTest4.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW9.h"
#include "DlgTest4.h"
#include "afxdialogex.h"


// CDlgTest4 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest4, CDialogEx)

CDlgTest4::CDlgTest4(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG3, pParent)
{

}

CDlgTest4::~CDlgTest4()
{
}

void CDlgTest4::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgTest4, CDialogEx)
END_MESSAGE_MAP()


// CDlgTest4 �T���B�z�`��
