// DlgTest3.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW9.h"
#include "DlgTest3.h"
#include "afxdialogex.h"


// CDlgTest3 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest3, CDialogEx)

CDlgTest3::CDlgTest3(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG2, pParent)
	, m_guess(0)
	, m_fail(0)
{
	srand(time(NULL));
	Ans = rand() % 10;
}

CDlgTest3::~CDlgTest3()
{
}

void CDlgTest3::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT2, m_guess);
	DDX_Text(pDX, IDC_EDIT1, m_fail);
}


BEGIN_MESSAGE_MAP(CDlgTest3, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest3::OnBnClickedButton1)
END_MESSAGE_MAP()


// CDlgTest3 �T���B�z�`��


void CDlgTest3::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);

	if (m_guess == Ans) 
	{
		AfxMessageBox(_T("Correct guess!"));
		Ans = rand() % 10;
		m_fail = 0;
	}
	else 
	{
		m_fail += 1;
		if (m_fail == 3) 
		{
			AfxMessageBox(_T("Fail..."));
			Ans = rand() % 10;
			m_fail = 0;
		}
		else 
		{
			AfxMessageBox(_T("Wrong guess"));
		}
	}

	UpdateData(FALSE);
}
