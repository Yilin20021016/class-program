// DlgTest5.cpp : ��@��
//

#include "stdafx.h"
#include "110303512_HW9.h"
#include "DlgTest5.h"
#include "afxdialogex.h"


// CDlgTest5 ��ܤ��

IMPLEMENT_DYNAMIC(CDlgTest5, CDialogEx)

CDlgTest5::CDlgTest5(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG4, pParent)
	, m_high(0)
	, m_weight(0)
	, m_BMI(0)
{

}

CDlgTest5::~CDlgTest5()
{
}

void CDlgTest5::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_high);
	DDX_Text(pDX, IDC_EDIT2, m_weight);
	DDX_Text(pDX, IDC_EDIT3, m_BMI);
}


BEGIN_MESSAGE_MAP(CDlgTest5, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CDlgTest5::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, &CDlgTest5::OnBnClickedButton2)
END_MESSAGE_MAP()


// CDlgTest5 �T���B�z�`��


void CDlgTest5::OnBnClickedButton1()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	UpdateData(TRUE);
	high.push_back(m_high);
	weight.push_back(m_weight);
	m_BMI = m_weight / (m_high*m_high / 10000);
	BMI.push_back(m_BMI);
	UpdateData(FALSE);
}


void CDlgTest5::OnBnClickedButton2()
{
	// TODO: �b���[�J����i���B�z�`���{���X
	CString o2=_T("");
	for (int i = 0; i < BMI.size(); i++) 
	{
		CString str;
		str.Format(_T("%d\t%.2f\t%.2f\t%.2f\n"), i, high[i], weight[i], BMI[i]);
		o2 += str;
	}
	AfxMessageBox(_T("�s��\t����\t�魫\tBMI\n") + o2);
}
