#pragma once
#include <vector>
using namespace std;

// CDlgTest5 ��ܤ��

class CDlgTest5 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest5)

public:
	CDlgTest5(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest5();
	vector <double> high;
	vector <double> weight;
	vector <double> BMI;

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG4 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	double m_high;
	double m_weight;
	double m_BMI;
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
};
