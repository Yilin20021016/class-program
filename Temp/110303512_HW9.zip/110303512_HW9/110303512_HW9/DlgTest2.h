#pragma once


// CDlgTest2 ��ܤ��

class CDlgTest2 : public CDialogEx
{
	DECLARE_DYNAMIC(CDlgTest2)

public:
	CDlgTest2(CWnd* pParent = NULL);   // �зǫغc�禡
	virtual ~CDlgTest2();

// ��ܤ�����
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �䴩

	DECLARE_MESSAGE_MAP()
public:
	int m_num;
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
};
